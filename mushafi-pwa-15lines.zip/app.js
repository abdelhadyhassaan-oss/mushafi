/* مصحفي — القارئ الصفحي (15 سطراً لكل صفحة، آيات متدفقة) — بيانات تخطيط مصحف المدينة */
'use strict';

const SURAH_NAMES = [
  "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة", "يونس",
  "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه",
  "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم",
  "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر",
  "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "ق",
  "الذاريات", "الطور", "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة",
  "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج",
  "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
  "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد",
  "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات",
  "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر",
  "المسد", "الإخلاص", "الفلق", "الناس"
];

const state = {
  mushaf: null,      // صفحات 1..604 → مصفوفة خلايا (15 سطراً)
  basmala: '',
  ayahList: [],      // {s, a, page, t}
  surahStart: new Array(115).fill(0),
  surahCount: new Array(115).fill(0),
  screen: 'home',
  page: 1,
  indexTab: 'surahs',
  error: false,
  loaded: false,
  flash: null
};

function ar(n) { return String(n).replace(/\d/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'[d]; }); }

function normalizeArabic(v) {
  return v.normalize('NFD')
    .replace(/[\u064B-\u065F\u0670\u0640\u06D6-\u06ED\u08F0-\u08FF]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .trim().toLowerCase();
}

const store = {
  get dark() { return localStorage.getItem('mushafi.dark') === '1'; },
  set dark(v) { localStorage.setItem('mushafi.dark', v ? '1' : '0'); },
  get font() { var v = parseInt(localStorage.getItem('mushafi.font'), 10); return (v >= 16 && v <= 40) ? v : 22; },
  set font(v) { localStorage.setItem('mushafi.font', String(v)); },
  get pos() {
    try {
      var p = JSON.parse(localStorage.getItem('mushafi.pos'));
      if (p && p.p >= 1 && p.p <= 604) return p;
    } catch (e) {}
    return { s: 1, n: 1, p: 1 };
  },
  set pos(p) { localStorage.setItem('mushafi.pos', JSON.stringify(p)); },
  get marks() {
    try { return new Set(JSON.parse(localStorage.getItem('mushafi.marks') || '[]')); } catch (e) { return new Set(); }
  },
  set marks(set) { localStorage.setItem('mushafi.marks', JSON.stringify(Array.from(set))); }
};

function applyTheme() {
  document.body.classList.toggle('dark', store.dark);
  document.documentElement.style.setProperty('--base-font', store.font + 'px');
}

/* تحميل تخطيط المصحف الكامل (سطر بسطر) */
async function loadData() {
  var res = await fetch('./data/mushaf-lines.json');
  if (!res.ok) throw new Error('تعذر تحميل بيانات الصفحات');
  var data = await res.json();
  if (!data.pages || !data.pages[1] || !data.pages[604]) throw new Error('بيانات غير مكتملة');
  state.mushaf = data.pages;
  state.basmala = data.basmala;

  // بناء قائمة الآيات (للبحث والمحفوظات) + أول صفحة لكل سورة
  var seen = {};
  for (var p = 1; p <= 604; p++) {
    var slots = state.mushaf[p];
    for (var i = 0; i < slots.length; i++) {
      var sl = slots[i];
      if (!sl.t) continue;
      for (var j = 0; j < sl.t.length; j++) {
        var tok = sl.t[j];
        var s = tok[0], a = tok[1], t = tok[2], f = tok[3] || 0;
        if ((f & 2) && !seen[s + ':' + a]) { // بداية آية
          seen[s + ':' + a] = { s: s, a: a, page: p, t: '' };
          state.ayahList.push(seen[s + ':' + a]);
          if (a === 1 && !state.surahStart[s]) state.surahStart[s] = p;
        }
        var cur = seen[s + ':' + a];
        if (cur) {
          if (!(f & 1)) { if (cur.t) cur.t += ' '; cur.t += t; }
          else if (!cur.t) cur.t = t;
        }
      }
    }
  }
  if (state.ayahList.length !== 6236) throw new Error('عدد الآيات غير مطابق: ' + state.ayahList.length);
  state.ayahList.forEach(function (a) { state.surahCount[a.s]++; });
  for (var sn = 1; sn <= 114; sn++) {
    if (!state.surahStart[sn]) throw new Error('لم تُعثر على صفحة بداية السورة ' + sn);
  }
}

const NAV = [
  { id: 'home', label: 'الرئيسية', icon: '⌂' },
  { id: 'index', label: 'الفهرس', icon: '۞' },
  { id: 'search', label: 'بحث', icon: '⌕' },
  { id: 'marks', label: 'المحفوظات', icon: '☆' },
  { id: 'settings', label: 'الإعدادات', icon: '⚙' }
];

function buildNav() {
  var nav = document.getElementById('bottomNav');
  nav.innerHTML = '';
  NAV.forEach(function (item) {
    var b = document.createElement('button');
    if (state.screen === item.id) b.className = 'active';
    b.innerHTML = '<span class="ic">' + item.icon + '</span><span>' + item.label + '</span>';
    b.onclick = function () { go(item.id); };
    nav.appendChild(b);
  });
}

function go(screen) { state.screen = screen; render(); window.scrollTo(0, 0); }

function openPage(p, flashAyah) {
  state.page = Math.min(604, Math.max(1, p));
  state.flash = flashAyah || null;
  state.screen = 'reader';
  store.pos = { s: store.pos.s, n: store.pos.n, p: state.page };
  render();
}

function esc(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }

/* ===== القارئ: صفحة من 15 سطراً ===== */
function renderReader() {
  var slots = state.mushaf[state.page];
  if (!slots) { state.page = 1; slots = state.mushaf[1]; }
  var marks = store.marks;
  var rows = '';
  slots.forEach(function (sl) {
    if (sl.h) {
      var sn = parseInt(sl.h.replace(/\D/g, ''), 10);
      rows += '<div class="mline mheader"><span class="sband">﴾ سورة ' + esc(SURAH_NAMES[sn - 1]) + ' ﴿</span></div>';
    } else if (sl.b && !sl.t) {
      rows += '<div class="mline mbasmala"><span class="lcontent">' + esc(state.basmala) + '</span></div>';
    } else {
      var inner = '';
      if (sl.b) inner += '<span class="basmala-inline">' + esc(state.basmala) + '</span> ';
      sl.t.forEach(function (tok) {
        var s = tok[0], a = tok[1], t = tok[2], f = tok[3] || 0;
        var isEnd = (f & 1) !== 0, isStart = (f & 2) !== 0;
        var id = isStart ? ' id="a' + s + '_' + a + '"' : '';
        if (isEnd) {
          var on = marks.has(s + ':' + a);
          inner += '<span class="amark' + (on ? ' on' : '') + '" data-k="' + s + ':' + a + '" title="حفظ الآية"' + id + '>﴿' + ar(a) + '﴾</span> ';
        } else {
          inner += '<span class="word"' + id + '>' + esc(t) + '</span> ';
        }
      });
      rows += '<div class="mline mtext"><div class="lcontent">' + inner + '</div></div>';
    }
  });
  for (var pad = slots.length; pad < 15; pad++) rows += '<div class="mline mempty"></div>';

  document.getElementById('app').innerHTML =
    '<div class="reader" id="readerRoot">' +
    '<div class="r-body" id="rbody">' + rows + '</div>' +
    '<div class="r-foot">' +
    '<button class="pbtn" id="prevBtn" title="الصفحة السابقة">›</button>' +
    '<div class="pinfo">صفحة ' + ar(state.page) + ' / ' + ar(604) + '</div>' +
    '<button class="pbtn" id="nextBtn" title="الصفحة التالية">‹</button>' +
    '</div></div>';

  document.getElementById('prevBtn').onclick = function () { turnPage(-1); };
  document.getElementById('nextBtn').onclick = function () { turnPage(1); };

  document.querySelectorAll('.amark').forEach(function (m) {
    m.onclick = function () {
      var k = m.dataset.k;
      var set = store.marks;
      var on;
      if (set.has(k)) { set.delete(k); on = false; } else { set.add(k); on = true; }
      store.marks = set;
      m.classList.toggle('on', on);
      var row = m.closest('.mline');
      row.classList.remove('flash'); void row.offsetWidth; row.classList.add('flash');
    };
  });

  attachSwipe(document.getElementById('readerRoot'));
  document.onkeydown = function (e) {
    if (state.screen !== 'reader') return;
    if (e.key === 'ArrowLeft') turnPage(1);
    else if (e.key === 'ArrowRight') turnPage(-1);
  };

  requestAnimationFrame(function () {
    fitPage();
    if (state.flash) {
      var el = document.getElementById(state.flash);
      if (el) {
        el.scrollIntoView({ block: 'center' });
        var row = el.closest('.mline');
        if (row) { row.classList.add('flash'); setTimeout(function () { row.classList.remove('flash'); }, 1600); }
      }
    }
  });
}

/* ملاءمة عرض السطور: كل سطر يمتد لحافة الصفحة (زي ورق المصحف) */
function fitPage() {
  var body = document.getElementById('rbody');
  if (!body) return;
  var lines = body.querySelectorAll('.mtext .lcontent, .mbasmala .lcontent');
  if (!lines.length) return;
  var W = body.clientWidth - 10;
  var max = 0;
  lines.forEach(function (l) {
    l.style.whiteSpace = 'nowrap';
    if (l.scrollWidth > max) max = l.scrollWidth;
    l.style.whiteSpace = '';
  });
  if (max > 0) {
    var scale = Math.min(1.3, Math.max(0.55, W / max));
    var fs = Math.max(13, Math.min(store.font, Math.round(store.font * scale)));
    body.style.setProperty('--line-font', fs + 'px');
  }
}

function turnPage(delta) {
  var p = state.page + delta;
  if (p < 1 || p > 604) return;
  openPage(p);
}

var touchX = null, touchY = null;
function attachSwipe(root) {
  root.addEventListener('touchstart', function (e) { touchX = e.touches[0].clientX; touchY = e.touches[0].clientY; }, { passive: true });
  root.addEventListener('touchend', function (e) {
    if (touchX === null) return;
    var dx = e.changedTouches[0].clientX - touchX;
    var dy = e.changedTouches[0].clientY - touchY;
    touchX = null;
    if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5) {
      if (dx < 0) turnPage(1); else turnPage(-1);
    }
  }, { passive: true });
}

function detachReader() { document.onkeydown = null; }

/* ===== باقي الشاشات ===== */
function renderLoading(msg) {
  document.getElementById('app').innerHTML = '<div class="loading">' + (msg || 'جارٍ التحميل…') + '</div>';
}

function renderError() {
  document.getElementById('app').innerHTML =
    '<div class="page"><div class="center-note">تعذّر تحميل نص المصحف.<br>تأكد من فتح التطبيق مرة واحدة عبر الإنترنت، بعدها سيعمل دون اتصال.</div>' +
    '<div style="text-align:center"><button class="btn" id="retryBtn">إعادة المحاولة</button></div></div>';
  document.getElementById('retryBtn').onclick = boot;
}

function renderHome() {
  var p = store.pos;
  var app = document.getElementById('app');
  app.innerHTML =
    '<div class="page">' +
    '<h1 class="title">مصحفي</h1>' +
    '<p class="subtitle">رفيق قراءتك اليومية</p>' +
    '<button class="linklike" id="continueCard"><div class="continue">' +
    '<div class="big">متابعة القراءة</div>' +
    '<div class="pos">' + esc(SURAH_NAMES[p.s - 1]) + ' · الآية ' + ar(p.n) + ' · صفحة ' + ar(p.p) + '</div>' +
    '<div class="open">افتح المصحف ←</div>' +
    '</div></button>' +
    '<div class="card"><button class="linklike" id="goIndex"><div class="c-title">الفهرس</div><div class="c-sub">' + ar(114) + ' سورة · ' + ar(604) + ' صفحة</div></button></div>' +
    '<div class="card"><button class="linklike" id="goSearch"><div class="c-title">البحث</div><div class="c-sub">في آيات القرآن</div></button></div>' +
    '<div class="card"><button class="linklike" id="goMarks"><div class="c-title">الآيات المحفوظة</div><div class="c-sub">إشاراتك المرجعية</div></button></div>' +
    '<p style="font-weight:700;font-size:19px;margin:18px 0 4px">ابدأ رحلتك</p>' +
    '<p style="opacity:.75;line-height:1.7;margin-top:0">مصحف المدينة كاملاً: ' + ar(604) + ' صفحة × 15 سطراً، آيات متدفقة بترقيم عثماني — دون اتصال.</p>' +
    '</div>';
  document.getElementById('continueCard').onclick = function () { openPage(p.p, 'a' + p.s + '_' + p.n); };
  document.getElementById('goIndex').onclick = function () { go('index'); };
  document.getElementById('goSearch').onclick = function () { go('search'); };
  document.getElementById('goMarks').onclick = function () { go('marks'); };
}

function renderIndex() {
  var tabs = '<div class="tabs"><button id="tabS"' + (state.indexTab === 'surahs' ? ' class="on"' : '') + '>السور</button>' +
    '<button id="tabP"' + (state.indexTab === 'pages' ? ' class="on"' : '') + '>الصفحات</button></div>';
  var content = '';
  if (state.indexTab === 'surahs') {
    var rows = '';
    for (var s = 1; s <= 114; s++) {
      rows += '<div class="surah-row" data-p="' + state.surahStart[s] + '" data-s="' + s + '">' +
        '<div class="surah-num">' + ar(s) + '</div>' +
        '<div class="meta">' + esc(SURAH_NAMES[s - 1]) + '</div>' +
        '<div class="range">صفحة ' + ar(state.surahStart[s]) + ' · ' + ar(state.surahCount[s]) + ' آية</div>' +
        '</div>';
    }
    content = '<div class="card" style="padding:6px 14px">' + rows + '</div>';
  } else {
    var grid = '';
    for (var pg = 1; pg <= 604; pg++) grid += '<button class="pg" data-p="' + pg + '">' + ar(pg) + '</button>';
    content = '<div class="pggrid">' + grid + '</div>';
  }
  document.getElementById('app').innerHTML = '<div class="page"><h1 class="title" style="font-size:25px">الفهرس</h1>' + tabs + content + '</div>';
  document.getElementById('tabS').onclick = function () { state.indexTab = 'surahs'; renderIndex(); };
  document.getElementById('tabP').onclick = function () { state.indexTab = 'pages'; renderIndex(); };
  document.querySelectorAll('[data-p]').forEach(function (row) {
    row.onclick = function () {
      var s = row.dataset.s ? parseInt(row.dataset.s, 10) : 1;
      openPage(parseInt(row.dataset.p, 10), row.dataset.s ? 'a' + s + '_1' : null);
    };
  });
}

var normCache = null;
function normalizedAyahs() {
  if (!normCache) {
    normCache = state.ayahList.map(function (a, i) { return { i: i, n: normalizeArabic(a.t) }; });
  }
  return normCache;
}

function renderSearch() {
  document.getElementById('app').innerHTML =
    '<div class="page">' +
    '<h1 class="title" style="font-size:25px">البحث في الآيات</h1>' +
    '<input class="searchbar" id="q" type="search" placeholder="اكتب كلمة أو جزءاً من آية…" autocomplete="off">' +
    '<div id="results"><div class="center-note">يتجاهل البحث التشكيل واختلاف الهمزات.</div></div>' +
    '</div>';
  var q = document.getElementById('q');
  q.focus();
  q.addEventListener('input', function () {
    var term = normalizeArabic(q.value.trim());
    var box = document.getElementById('results');
    if (term.length < 2) { box.innerHTML = '<div class="center-note">اكتب حرفين على الأقل للبحث.</div>'; return; }
    var all = normalizedAyahs();
    var hits = [];
    for (var i = 0; i < all.length && hits.length < 300; i++) {
      if (all[i].n.indexOf(term) !== -1) hits.push(state.ayahList[all[i].i]);
    }
    if (!hits.length) { box.innerHTML = '<div class="center-note">لا توجد نتائج مطابقة.</div>'; return; }
    var html = '<div class="result-note">' + ar(hits.length) + (hits.length >= 300 ? '+' : '') + ' نتيجة — اضغط الآية لفتح صفحتها</div>';
    hits.forEach(function (a) {
      html += '<div class="card hit" data-p="' + a.page + '" data-f="a' + a.s + '_' + a.a + '">' +
        '<div class="c-title">سورة ' + esc(SURAH_NAMES[a.s - 1]) + ' · الآية ' + ar(a.a) + ' · صفحة ' + ar(a.page) + '</div>' +
        '<div class="atext">' + esc(a.t) + '</div></div>';
    });
    box.innerHTML = html;
    box.querySelectorAll('.hit').forEach(function (c) {
      c.onclick = function () { openPage(parseInt(c.dataset.p, 10), c.dataset.f); };
    });
  });
}

function renderMarks() {
  var marks = Array.from(store.marks).sort(function (x, y) {
    var a = x.split(':'), b = y.split(':');
    return (+a[0] - +b[0]) || (+a[1] - +b[1]);
  });
  if (!marks.length) {
    document.getElementById('app').innerHTML = '<div class="page"><h1 class="title" style="font-size:25px">الآيات المحفوظة</h1><div class="center-note">لا توجد آيات محفوظة بعد.<br>اضغط رقم الآية ﴿١﴾ في الصفحة لحفظها هنا.</div></div>';
    return;
  }
  var html = '<div class="page"><h1 class="title" style="font-size:25px">الآيات المحفوظة</h1>';
  marks.forEach(function (k) {
    var parts = k.split(':'), s = +parts[0], n = +parts[1];
    var a = state.ayahList.find(function (x) { return x.s === s && x.a === n; });
    if (a) {
      html += '<div class="card hit" data-p="' + a.page + '" data-f="a' + s + '_' + n + '">' +
        '<div class="c-title">سورة ' + esc(SURAH_NAMES[s - 1]) + ' · الآية ' + ar(n) + ' · صفحة ' + ar(a.page) + '</div>' +
        '<div class="atext" style="max-height:110px;overflow:hidden">' + esc(a.t) + '</div></div>';
    }
  });
  document.getElementById('app').innerHTML = html + '</div>';
  document.querySelectorAll('.hit').forEach(function (c) {
    c.onclick = function () { openPage(parseInt(c.dataset.p, 10), c.dataset.f); };
  });
}

function renderSettings() {
  var app = document.getElementById('app');
  app.innerHTML =
    '<div class="page">' +
    '<h1 class="title" style="font-size:25px">الإعدادات</h1>' +
    '<div class="card">' +
    '<div class="setting-row"><div class="lbl">الوضع الليلي</div>' +
    '<label class="switch"><input type="checkbox" id="darkSw"' + (store.dark ? ' checked' : '') + '><span class="track"></span></label></div>' +
    '<div class="setting-row" style="display:block"><div class="lbl" style="margin-bottom:8px">حجم الخط الأساسي: <span id="fontVal">' + ar(store.font) + '</span></div>' +
    '<input type="range" id="fontR" min="16" max="40" step="1" value="' + store.font + '"><div class="c-sub" style="margin-top:6px">تُضبط السطور تلقائياً لتمتد من حافة الصفحة لحافتها.</div></div>' +
    '</div>' +
    '<p style="opacity:.6">مصحفي · الإصدار 0.3.0 — صفحات المصحف المدني (15 سطراً)</p>' +
    '<p style="opacity:.7;line-height:1.7">النص العثماني: Tanzil Project · ترخيص CC BY 3.0. تخطيط السطور: ترقيم مصحف المدينة المعتمد. الخط: أميري (OFL).</p>' +
    '</div>';
  document.getElementById('darkSw').onchange = function (e) { store.dark = e.target.checked; applyTheme(); };
  document.getElementById('fontR').oninput = function (e) {
    store.font = parseInt(e.target.value, 10);
    applyTheme();
    document.getElementById('fontVal').textContent = ar(store.font);
  };
}

function render() {
  detachReader();
  applyTheme();
  buildNav();
  if (state.error) { renderError(); return; }
  if (!state.loaded) { renderLoading('جارٍ تحميل المصحف (مرة واحدة فقط، بعدها يعمل دون اتصال)…'); return; }
  switch (state.screen) {
    case 'index': renderIndex(); break;
    case 'reader': renderReader(); break;
    case 'search': renderSearch(); break;
    case 'marks': renderMarks(); break;
    case 'settings': renderSettings(); break;
    default: renderHome();
  }
}

async function boot() {
  state.error = false;
  render();
  try {
    await loadData();
    state.loaded = true;
    render();
  } catch (e) {
    state.error = true;
    render();
  }
}

boot();
