package com.abdelhady.mushafi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
