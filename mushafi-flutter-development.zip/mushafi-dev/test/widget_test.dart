import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mushafi/data/quran_repository.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('بيانات القرآن الكريم', () {
    setUpAll(() async {
      await QuranRepository.instance.load();
    });

    test('عدد السور 114', () {
      expect(QuranRepository.instance.surahs.length, 114);
    });

    test('عدد الآيات 6236', () {
      expect(QuranRepository.instance.ayahs.length, 6236);
    });

    test('عدد صفحات المصحف 604 وكل صفحة 15 سطرًا', () {
      final repo = QuranRepository.instance;
      expect(repo.pages.length, 604);
      for (final p in repo.pages) {
        for (final line in p.lines) {
          expect(line.number, inInclusiveRange(1, 15));
        }
      }
    });

    test('كل السور لها سطر عنوان في المصحف', () {
      final repo = QuranRepository.instance;
      final found = <int>{};
      for (final p in repo.pages) {
        found.addAll(p.banners.values);
      }
      for (var s = 1; s <= 114; s++) {
        expect(found.contains(s), isTrue, reason: 'سورة $s بدون عنوان');
      }
    });

    test('فهرس الآيات متصل وصحيح', () {
      final repo = QuranRepository.instance;
      for (var i = 0; i < repo.surahs.length; i++) {
        final s = repo.surahs[i];
        final expectedStart = i == 0
            ? 1
            : repo.surahs[i - 1].startIndex + repo.surahs[i - 1].ayahCount;
        expect(s.startIndex, expectedStart);
        expect(repo.ayahsOfSurah(s.number).length, s.ayahCount);
      }
    });

    test('تحديد موقع الآية الأولى في السورة الثانية', () {
      final repo = QuranRepository.instance;
      final loc = repo.locateGlobal(repo.globalIndex(2, 1));
      expect(loc.surah, 2);
      expect(loc.ayah, 1);
    });

    test('البحث يتجاهل التشكيل', () {
      final hits = QuranRepository.instance.search('الرحمن');
      expect(hits, isNotEmpty);
    });

    test('تطبيع النص العربي', () {
      expect(QuranRepository.normalize('الرَّحْمَٰنِ'), 'الرحمن');
    });
  });

  testWidgets('التطبيق يعرض شاشة البداية', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(body: Center(child: Text('المصحف'))),
      ),
    );
    expect(find.text('المصحف'), findsOneWidget);
  });
}
