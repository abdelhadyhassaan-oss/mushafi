import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../data/quran_repository.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/islamic_pattern.dart';
import 'reader_screen.dart';
import 'juz_list_screen.dart';
import 'bookmarks_screen.dart';
import 'search_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final screens = [
      const _QuranTab(),
      const JuzListScreen(),
      const BookmarksScreen(),
      const SettingsScreen(),
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: IndexedStack(index: _tab, children: screens),
        bottomNavigationBar: Container(
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.08),
                blurRadius: 18,
                offset: const Offset(0, -4),
              ),
            ],
          ),
          child: SafeArea(
            top: false,
            child: NavigationBar(
              selectedIndex: _tab,
              height: 64,
              backgroundColor: Colors.transparent,
              indicatorColor: AppTheme.gold.withValues(alpha: 0.20),
              labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
              onDestinationSelected: (i) => setState(() => _tab = i),
              destinations: const [
                NavigationDestination(
                  icon: Icon(Icons.menu_book_outlined),
                  selectedIcon: Icon(Icons.menu_book),
                  label: 'المصحف',
                ),
                NavigationDestination(
                  icon: Icon(Icons.grid_view_outlined),
                  selectedIcon: Icon(Icons.grid_view_rounded),
                  label: 'الأجزاء',
                ),
                NavigationDestination(
                  icon: Icon(Icons.bookmark_border),
                  selectedIcon: Icon(Icons.bookmark),
                  label: 'العلامات',
                ),
                NavigationDestination(
                  icon: Icon(Icons.settings_outlined),
                  selectedIcon: Icon(Icons.settings),
                  label: 'الإعدادات',
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _QuranTab extends StatefulWidget {
  const _QuranTab();

  @override
  State<_QuranTab> createState() => _QuranTabState();
}

class _QuranTabState extends State<_QuranTab> {
  final _repo = QuranRepository.instance;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final isLight = !state.darkMode;

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(child: _buildHeader(context, state)),
        SliverToBoxAdapter(child: _buildContinueCard(context, state)),
        SliverToBoxAdapter(child: _buildQuickActions(context, state)),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(16, 22, 16, 8),
          sliver: SliverToBoxAdapter(
            child: Row(
              children: [
                Container(
                  width: 4,
                  height: 20,
                  decoration: BoxDecoration(
                    gradient: AppTheme.goldGradient,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  'فهرس السور',
                  style: TextStyle(
                    fontFamily: 'Amiri',
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    color: isLight ? AppTheme.ink : Colors.white,
                  ),
                ),
                const Spacer(),
                Text(
                  '${_repo.surahs.length} سورة',
                  style: TextStyle(
                    fontFamily: 'Amiri',
                    fontSize: 14,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(14, 4, 14, 90),
          sliver: SliverList.separated(
            itemCount: _repo.surahs.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) => _SurahTile(surah: _repo.surahs[i]),
          ),
        ),
      ],
    );
  }

  Widget _buildHeader(BuildContext context, AppState state) {
    return Container(
      decoration: const BoxDecoration(
        gradient: AppTheme.headerGradient,
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Stack(
          children: [
            Positioned(
              left: -30,
              top: -20,
              child: IslamicPattern(size: 160, color: Colors.white),
            ),
            Positioned(
              right: -40,
              bottom: -30,
              child: IslamicPattern(size: 130, color: AppTheme.goldLight),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 26),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'المصحف الشريف',
                              style: TextStyle(
                                fontFamily: 'Amiri',
                                fontSize: 26,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'القرآن الكريم بالرسم العثماني',
                              style: TextStyle(
                                fontFamily: 'Amiri',
                                fontSize: 13,
                                color: Colors.white.withValues(alpha: 0.82),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _CircleIconButton(
                        icon: Icons.search_rounded,
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => const SearchScreen(),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      _CircleIconButton(
                        icon: state.darkMode
                            ? Icons.light_mode_rounded
                            : Icons.dark_mode_rounded,
                        onTap: state.toggleDark,
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  // آية اليوم
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 18,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.13),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: AppTheme.goldLight.withValues(alpha: 0.35),
                      ),
                    ),
                    child: Column(
                      children: [
                        const Text(
                          '﴿ إِنَّا أَنزَلْنَا الْقُرْآنَ تَنزِيلًا ﴾',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontFamily: 'AmiriQuran',
                            fontSize: 22,
                            color: Colors.white,
                            height: 1.9,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'سورة الإنسان',
                          style: TextStyle(
                            fontFamily: 'Amiri',
                            fontSize: 12,
                            color: AppTheme.goldLight.withValues(alpha: 0.95),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContinueCard(BuildContext context, AppState state) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
      child: OrnateFrame(
        fillColor: Theme.of(context).colorScheme.surface,
        borderColor: AppTheme.gold,
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => ReaderScreen(
                  surahNumber: state.lastSurah,
                  initialAyah: state.lastAyah,
                ),
              ),
            );
          },
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    gradient: AppTheme.goldGradient,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Icon(
                    Icons.play_arrow_rounded,
                    color: Colors.white,
                    size: 28,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        state.hasProgress ? 'متابعة القراءة' : 'ابدأ القراءة',
                        style: const TextStyle(
                          fontFamily: 'Amiri',
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'سورة ${_repo.surahByNumber(state.lastSurah).shortName} • الآية ${state.lastAyah}',
                        style: TextStyle(
                          fontFamily: 'Amiri',
                          fontSize: 13,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.arrow_back_ios_new_rounded,
                  size: 16,
                  color: Colors.grey.shade500,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildQuickActions(BuildContext context, AppState state) {
    final actions = [
      (
        'الجزء',
        Icons.layers_outlined,
        () => _openJuz(context, state.lastSurah, state.lastAyah),
      ),
      (
        'الصفحة',
        Icons.auto_stories_outlined,
        () => _openPage(context, state.lastSurah, state.lastAyah),
      ),
      (
        'بحث',
        Icons.search,
        () => Navigator.of(
          context,
        ).push(MaterialPageRoute(builder: (_) => const SearchScreen())),
      ),
      (
        'العلامات',
        Icons.bookmarks_outlined,
        () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => const BookmarksScreen(standalone: true),
          ),
        ),
      ),
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Row(
        children: actions.map((a) {
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: a.$3,
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surface,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(
                      color: AppTheme.emerald.withValues(alpha: 0.12),
                    ),
                  ),
                  child: Column(
                    children: [
                      Icon(a.$2, size: 22, color: AppTheme.emerald),
                      const SizedBox(height: 6),
                      Text(
                        a.$1,
                        style: const TextStyle(
                          fontFamily: 'Amiri',
                          fontSize: 12.5,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  void _openJuz(BuildContext context, int surah, int ayah) {
    final idx = _repo.globalIndex(surah, ayah);
    final juz = _repo.ayahAt(idx).juz;
    Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (_) => ReaderScreen(juzNumber: juz)));
  }

  void _openPage(BuildContext context, int surah, int ayah) {
    final idx = _repo.globalIndex(surah, ayah);
    final page = _repo.ayahAt(idx).page;
    Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (_) => ReaderScreen(pageNumber: page)));
  }
}

class _CircleIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _CircleIconButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withValues(alpha: 0.16),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(9),
          child: Icon(icon, size: 20, color: Colors.white),
        ),
      ),
    );
  }
}

class _SurahTile extends StatelessWidget {
  final Surah surah;
  const _SurahTile({required this.surah});

  static String _arabic(int n) {
    const w = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    const a = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    var s = n.toString();
    for (var i = 0; i < 10; i++) {
      s = s.replaceAll(w[i], a[i]);
    }
    return s;
  }

  @override
  Widget build(BuildContext context) {
    final isLight = Theme.of(context).brightness == Brightness.light;

    return Material(
      color: Theme.of(context).colorScheme.surface,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          HapticFeedback.selectionClick();
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => ReaderScreen(surahNumber: surah.number),
            ),
          );
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: isLight
                  ? Colors.black.withValues(alpha: 0.05)
                  : Colors.white.withValues(alpha: 0.06),
            ),
          ),
          child: Row(
            children: [
              // رقم السورة داخل نجمة
              SizedBox(
                width: 42,
                height: 42,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        color: AppTheme.emerald.withValues(alpha: 0.08),
                        shape: BoxShape.circle,
                      ),
                    ),
                    Transform.rotate(
                      angle: 0.785,
                      child: Container(
                        width: 30,
                        height: 30,
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: AppTheme.gold.withValues(alpha: 0.55),
                          ),
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                    ),
                    Text(
                      '${surah.number}',
                      style: const TextStyle(
                        fontFamily: 'Amiri',
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.emerald,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      surah.shortName,
                      style: const TextStyle(
                        fontFamily: 'Amiri',
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${surah.type} • ${surah.ayahCount} آية',
                      style: TextStyle(
                        fontFamily: 'Amiri',
                        fontSize: 12.5,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
              ),
              Text(
                'ص ${_arabic(QuranRepository.instance.ayahAt(surah.startIndex - 1).page)}',
                style: TextStyle(
                  fontFamily: 'Amiri',
                  fontSize: 12.5,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.gold.withValues(alpha: 0.95),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
