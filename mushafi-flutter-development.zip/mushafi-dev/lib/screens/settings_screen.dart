import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/audio_service.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';

/// الإعدادات
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final isLight = Theme.of(context).brightness == Brightness.light;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: AppTheme.headerGradient,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(28),
                bottomRight: Radius.circular(28),
              ),
            ),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'الإعدادات',
                      style: TextStyle(
                        fontFamily: 'Amiri',
                        fontSize: 24,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'خصّص تجربة قراءتك',
                      style: TextStyle(
                        fontFamily: 'Amiri',
                        fontSize: 12.5,
                        color: Colors.white.withValues(alpha: 0.8),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),

          _groupTitle(context, 'المظهر والقراءة'),
          _card(context, [
            SwitchListTile(
              value: state.darkMode,
              onChanged: (_) => state.toggleDark(),
              activeThumbColor: AppTheme.gold,
              secondary: const Icon(
                Icons.dark_mode_outlined,
                color: AppTheme.emerald,
              ),
              title: const Text(
                'الوضع الليلي',
                style: TextStyle(fontFamily: 'Amiri', fontSize: 16),
              ),
              subtitle: Text(
                'واجهة داكنة مريحة للعين',
                style: TextStyle(
                  fontFamily: 'Amiri',
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),
            ),
            const Divider(height: 1),
            SwitchListTile(
              value: state.nightReadingMode,
              onChanged: (_) => state.toggleNightReading(),
              activeThumbColor: AppTheme.gold,
              secondary: const Icon(
                Icons.auto_stories_outlined,
                color: AppTheme.emerald,
              ),
              title: const Text(
                'وضع القراءة الليلي',
                style: TextStyle(fontFamily: 'Amiri', fontSize: 16),
              ),
              subtitle: Text(
                'خلفية ورقية دافئة أثناء القراءة',
                style: TextStyle(
                  fontFamily: 'Amiri',
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),
            ),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(
                Icons.format_size_rounded,
                color: AppTheme.emerald,
              ),
              title: const Text(
                'حجم خط الآيات',
                style: TextStyle(fontFamily: 'Amiri', fontSize: 16),
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 4),
                  Slider(
                    value: state.fontSize,
                    min: 18,
                    max: 46,
                    divisions: 14,
                    activeColor: AppTheme.emerald,
                    label: state.fontSize.round().toString(),
                    onChanged: state.setFontSize,
                  ),
                ],
              ),
            ),
          ]),

          _groupTitle(context, 'التلاوة الصوتية'),
          _card(context, [
            ListTile(
              leading: const Icon(
                Icons.record_voice_over_outlined,
                color: AppTheme.emerald,
              ),
              title: const Text(
                'القارئ',
                style: TextStyle(fontFamily: 'Amiri', fontSize: 16),
              ),
              subtitle: Text(
                reciterById(state.reciter).name,
                style: const TextStyle(
                  fontFamily: 'Amiri',
                  fontSize: 13,
                  color: AppTheme.gold,
                ),
              ),
              trailing: const Icon(Icons.chevron_left),
              onTap: () => _pickReciter(context, state),
            ),
          ]),

          _groupTitle(context, 'عن التطبيق'),
          _card(context, [
            ListTile(
              leading: const Icon(
                Icons.verified_outlined,
                color: AppTheme.emerald,
              ),
              title: const Text(
                'المصحف الشريف',
                style: TextStyle(fontFamily: 'Amiri', fontSize: 16),
              ),
              subtitle: Text(
                'الإصدار ١.٠.١ • القرآن الكريم بالرسم العثماني',
                style: TextStyle(
                  fontFamily: 'Amiri',
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),
            ),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.info_outline, color: AppTheme.emerald),
              title: const Text(
                'مصدر النص القرآني',
                style: TextStyle(fontFamily: 'Amiri', fontSize: 16),
              ),
              subtitle: Text(
                'الرسم العثماني برواية حفص عن عاصم',
                style: TextStyle(
                  fontFamily: 'Amiri',
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),
            ),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(
                Icons.headphones_outlined,
                color: AppTheme.emerald,
              ),
              title: const Text(
                'مصدر التلاوات',
                style: TextStyle(fontFamily: 'Amiri', fontSize: 16),
              ),
              subtitle: Text(
                'مكتبة everyayah.com — قرّاء متعددون',
                style: TextStyle(
                  fontFamily: 'Amiri',
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),
            ),
          ]),

          const SizedBox(height: 26),
          Center(
            child: Text(
              '﴿ وَنُنَزِّلُ مِنَ الْقُرْآنِ مَا هُوَ شِفَاءٌ وَرَحْمَةٌ ﴾',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'AmiriQuran',
                fontSize: 17,
                height: 2.0,
                color: AppTheme.gold.withValues(alpha: isLight ? 0.9 : 1.0),
              ),
            ),
          ),
          const SizedBox(height: 100),
        ],
      ),
    );
  }

  Widget _groupTitle(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 8, 22, 8),
      child: Row(
        children: [
          Container(
            width: 3,
            height: 15,
            decoration: BoxDecoration(
              gradient: AppTheme.goldGradient,
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            title,
            style: TextStyle(
              fontFamily: 'Amiri',
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: Theme.of(context).textTheme.bodyLarge?.color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _card(BuildContext context, List<Widget> children) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: Theme.of(context).brightness == Brightness.light
                ? Colors.black.withValues(alpha: 0.05)
                : Colors.white.withValues(alpha: 0.07),
          ),
        ),
        child: Column(children: children),
      ),
    );
  }

  void _pickReciter(BuildContext context, AppState state) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 14),
              const Text(
                'اختر القارئ',
                style: TextStyle(
                  fontFamily: 'Amiri',
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 8),
              ...kReciters.map(
                (r) => ListTile(
                  onTap: () {
                    state.setReciter(r.id);
                    Navigator.pop(ctx);
                  },
                  leading: Icon(
                    state.reciter == r.id
                        ? Icons.radio_button_checked
                        : Icons.radio_button_unchecked,
                    color: state.reciter == r.id
                        ? AppTheme.emerald
                        : Colors.grey.shade400,
                  ),
                  title: Text(
                    r.name,
                    style: TextStyle(
                      fontFamily: 'Amiri',
                      fontWeight: state.reciter == r.id
                          ? FontWeight.w700
                          : FontWeight.w400,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
            ],
          ),
        ),
      ),
    );
  }
}
