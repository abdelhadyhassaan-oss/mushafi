import 'package:flutter/material.dart';

import '../data/quran_repository.dart';
import '../theme/app_theme.dart';
import 'reader_screen.dart';

/// البحث في آيات القرآن الكريم
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _repo = QuranRepository.instance;
  final _controller = TextEditingController();
  List<SearchHit> _results = const [];
  bool _searched = false;
  bool _searching = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _run(String query) async {
    if (query.trim().length < 2) {
      setState(() {
        _results = const [];
        _searched = false;
      });
      return;
    }
    setState(() => _searching = true);
    await Future<void>.delayed(const Duration(milliseconds: 120));
    final hits = _repo.search(query);
    if (!mounted) return;
    setState(() {
      _results = hits;
      _searched = true;
      _searching = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: AppTheme.emerald,
          title: const Text('البحث في القرآن'),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: TextField(
                controller: _controller,
                autofocus: true,
                textInputAction: TextInputAction.search,
                onChanged: _run,
                onSubmitted: _run,
                style: const TextStyle(fontFamily: 'Amiri', fontSize: 17),
                decoration: InputDecoration(
                  hintText: 'ابحث عن كلمة أو عبارة...',
                  hintStyle: const TextStyle(
                    fontFamily: 'Amiri',
                    color: Colors.grey,
                  ),
                  prefixIcon: const Icon(Icons.search, color: AppTheme.emerald),
                  suffixIcon: _controller.text.isEmpty
                      ? null
                      : IconButton(
                          onPressed: () {
                            _controller.clear();
                            _run('');
                          },
                          icon: const Icon(Icons.close),
                        ),
                  filled: true,
                  fillColor: Theme.of(context).colorScheme.surface,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            Expanded(child: _buildBody()),
          ],
        ),
      ),
    );
  }

  Widget _buildBody() {
    if (_searching) {
      return const Center(child: CircularProgressIndicator());
    }
    if (!_searched) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.manage_search_rounded,
              size: 70,
              color: AppTheme.emerald.withValues(alpha: 0.35),
            ),
            const SizedBox(height: 14),
            Text(
              'اكتب كلمتين على الأقل للبحث',
              style: TextStyle(
                fontFamily: 'Amiri',
                fontSize: 15,
                color: Colors.grey.shade600,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'يتم تجاهل التشكيل أثناء البحث',
              style: TextStyle(
                fontFamily: 'Amiri',
                fontSize: 12.5,
                color: Colors.grey.shade500,
              ),
            ),
          ],
        ),
      );
    }
    if (_results.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.search_off_rounded,
              size: 70,
              color: Colors.grey.shade400,
            ),
            const SizedBox(height: 14),
            Text(
              'لا توجد نتائج مطابقة',
              style: TextStyle(
                fontFamily: 'Amiri',
                fontSize: 16,
                color: Colors.grey.shade600,
              ),
            ),
          ],
        ),
      );
    }

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
          child: Row(
            children: [
              Container(
                width: 4,
                height: 16,
                decoration: BoxDecoration(
                  gradient: AppTheme.goldGradient,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                '${_results.length} نتيجة',
                style: const TextStyle(
                  fontFamily: 'Amiri',
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
            itemCount: _results.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              final hit = _results[i];
              final loc = _repo.locateGlobal(hit.globalIndex);
              final surah = _repo.surahByNumber(loc.surah);
              return Material(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(16),
                child: InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => ReaderScreen(
                        surahNumber: loc.surah,
                        initialAyah: loc.ayah,
                      ),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          children: [
                            Icon(
                              Icons.menu_book_outlined,
                              size: 15,
                              color: AppTheme.gold,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              '${surah.shortName} • الآية ${loc.ayah}',
                              style: const TextStyle(
                                fontFamily: 'Amiri',
                                fontSize: 12.5,
                                fontWeight: FontWeight.w700,
                                color: AppTheme.emerald,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        _highlightedText(hit.ayah.text, _controller.text),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  /// إبراز الكلمة المطابقة داخل النص مع تجاهل التشكيل
  Widget _highlightedText(String text, String query) {
    final normText = QuranRepository.normalize(text);
    final normQuery = QuranRepository.normalize(query).trim();
    if (normQuery.isEmpty) return _plain(text);

    final matchIdx = normText.indexOf(normQuery);
    if (matchIdx < 0) return _plain(text);

    // ربط فهرس النص المجرّد بفهرس النص الأصلي
    var originalStart = -1;
    var originalEnd = -1;
    var normPos = 0;

    for (var i = 0; i < text.length; i++) {
      final ch = QuranRepository.normalize(text[i]);
      if (ch.isEmpty) continue;
      if (normPos == matchIdx && originalStart < 0) originalStart = i;
      if (normPos == matchIdx + normQuery.length - 1) {
        originalEnd = i + 1;
        break;
      }
      normPos += ch.length;
    }

    if (originalStart < 0 || originalEnd <= originalStart) return _plain(text);

    return Text.rich(
      TextSpan(
        children: [
          TextSpan(text: text.substring(0, originalStart)),
          TextSpan(
            text: text.substring(originalStart, originalEnd),
            style: const TextStyle(
              backgroundColor: Color(0x55C9A227),
              fontWeight: FontWeight.w700,
            ),
          ),
          TextSpan(text: text.substring(originalEnd)),
        ],
      ),
      style: TextStyle(
        fontFamily: 'AmiriQuran',
        fontSize: 16.5,
        height: 2.0,
        color: Theme.of(context).textTheme.bodyLarge?.color,
      ),
      maxLines: 3,
      overflow: TextOverflow.ellipsis,
      textDirection: TextDirection.rtl,
    );
  }

  Widget _plain(String text) => Text(
    text,
    maxLines: 3,
    overflow: TextOverflow.ellipsis,
    style: TextStyle(
      fontFamily: 'AmiriQuran',
      fontSize: 16.5,
      height: 2.0,
      color: Theme.of(context).textTheme.bodyLarge?.color,
    ),
    textDirection: TextDirection.rtl,
  );
}
