import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../data/quran_repository.dart';
import '../services/audio_service.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/mushaf_page_view.dart';
import '../utils/arabic.dart';

/// شاشة قراءة المصحف — صفحات مصحف المدينة (١٥ سطرًا)
class ReaderScreen extends StatefulWidget {
  final int? surahNumber;
  final int? juzNumber;
  final int? pageNumber;
  final int initialAyah;

  const ReaderScreen({
    super.key,
    this.surahNumber,
    this.juzNumber,
    this.pageNumber,
    this.initialAyah = 1,
  });

  @override
  State<ReaderScreen> createState() => _ReaderScreenState();
}

class _ReaderScreenState extends State<ReaderScreen> {
  final _repo = QuranRepository.instance;
  late final PageController _pageController;
  late int _page;
  String _title = '';
  String _subtitle = '';

  int? _selSurah;
  int? _selAyah;
  int? _selPage;

  @override
  void initState() {
    super.initState();
    _page = _resolveStartPage();
    _pageController = PageController(initialPage: _page - 1);
    _updateTitle();
    WidgetsBinding.instance.addPostFrameCallback((_) => _saveProgress(_page));
  }

  int _resolveStartPage() {
    if (widget.pageNumber != null) return widget.pageNumber!.clamp(1, 604);
    if (widget.juzNumber != null) {
      return _repo.pageOfJuz(widget.juzNumber!.clamp(1, 30));
    }
    if (widget.surahNumber != null) {
      return _repo.pageOf(widget.surahNumber!.clamp(1, 114), 1);
    }
    return 1;
  }

  void _updateTitle() {
    if (widget.surahNumber != null) {
      final s = _repo.surahByNumber(widget.surahNumber!);
      _title = s.shortName;
      _subtitle = '${s.type} • ${arNum(s.ayahCount)} آية';
    } else if (widget.juzNumber != null) {
      _title = 'الجزء ${arNum(widget.juzNumber!)}';
      final j = _repo.juzOfPage(_page);
      final s = _repo.surahByNumber(_firstSurahOfPage(_page));
      _subtitle = 'الجزء ${arNum(j)} • ${s.shortName}';
    } else {
      _title = 'المصحف الشريف';
      final s = _repo.surahByNumber(_firstSurahOfPage(_page));
      _subtitle = '${s.shortName} • الجزء ${arNum(_repo.juzOfPage(_page))}';
    }
  }

  int _firstSurahOfPage(int page) {
    final p = _repo.pages[page - 1];
    for (final l in p.lines) {
      for (final s in l.segments) {
        return s.surah;
      }
    }
    return 1;
  }

  void _saveProgress(int page) {
    final p = _repo.pages[page - 1];
    for (final l in p.lines.reversed) {
      for (final s in l.segments.reversed) {
        context.read<AppState>().saveProgress(s.surah, s.ayah);
        return;
      }
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _goToPage(int p) {
    final target = p.clamp(1, 604);
    _pageController.animateToPage(
      target - 1,
      duration: const Duration(milliseconds: 320),
      curve: Curves.easeOutCubic,
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final audio = context.watch<AudioPlayerService>();

    final paper = state.nightReadingMode
        ? const Color(0xFF14120D)
        : (Theme.of(context).brightness == Brightness.light
            ? const Color(0xFFFFFDF6)
            : const Color(0xFF16201C));
    final ink = state.nightReadingMode
        ? const Color(0xFFD9CEB2)
        : (Theme.of(context).brightness == Brightness.light
            ? const Color(0xFF14180F)
            : const Color(0xFFE9F0EB));

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: state.nightReadingMode
            ? const Color(0xFF0A0A07)
            : (Theme.of(context).brightness == Brightness.light
                ? const Color(0xFFEDE7D6)
                : const Color(0xFF0E1512)),
        body: Column(
          children: [
            _buildTopBar(context, state),
            Expanded(
              child: PageView.builder(
                controller: _pageController,
                // اتجاه التقليب: السحب من اليمين إلى اليسار ⇒ الصفحة التالية
                reverse: true,
                itemCount: 604,
                onPageChanged: (i) {
                  setState(() {
                    _page = i + 1;
                    _selSurah = null;
                    _selAyah = null;
                    _selPage = null;
                  });
                  _updateTitle();
                  _saveProgress(_page);
                },
                itemBuilder: (context, i) => _buildPage(
                  context,
                  i + 1,
                  state,
                  paper,
                  ink,
                ),
              ),
            ),
            _buildBottomBar(context, state, audio),
          ],
        ),
      ),
    );
  }

  Widget _buildTopBar(BuildContext context, AppState state) {
    return Container(
      decoration: const BoxDecoration(gradient: AppTheme.headerGradient),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(6, 4, 6, 10),
          child: Row(
            children: [
              IconButton(
                onPressed: () => Navigator.of(context).pop(),
                icon: const Icon(Icons.arrow_forward_rounded,
                    color: Colors.white),
              ),
              Expanded(
                child: Column(
                  children: [
                    Text(
                      _title,
                      style: const TextStyle(
                        fontFamily: 'Amiri',
                        fontSize: 19,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      _subtitle,
                      style: TextStyle(
                        fontFamily: 'Amiri',
                        fontSize: 11,
                        color: Colors.white.withValues(alpha: 0.78),
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: () => _showFontSheet(context, state),
                icon: const Icon(Icons.text_fields_rounded, color: Colors.white),
              ),
              IconButton(
                onPressed: state.toggleNightReading,
                icon: Icon(
                  state.nightReadingMode
                      ? Icons.wb_sunny_rounded
                      : Icons.nightlight_round,
                  color:
                      state.nightReadingMode ? AppTheme.goldLight : Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// إطار صفحة المصحف
  Widget _buildPage(
    BuildContext context,
    int pageNum,
    AppState state,
    Color paper,
    Color ink,
  ) {
    final page = _repo.pages[pageNum - 1];

    return LayoutBuilder(
      builder: (context, constraints) {
        final w = constraints.maxWidth;
        final h = constraints.maxHeight;
        final padX = w * 0.032;
        final padY = h * 0.011;

        return Container(
          margin: EdgeInsets.symmetric(
            horizontal: w > 520 ? (w - 520) / 2 : 0,
            vertical: 6,
          ),
          decoration: BoxDecoration(
            color: paper,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: AppTheme.gold.withValues(alpha: 0.45),
              width: 1.6,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.16),
                blurRadius: 14,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(9),
            child: Stack(
              children: [
                // إطار داخلي مزخرف
                Positioned.fill(
                  child: Padding(
                    padding: const EdgeInsets.all(6),
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: AppTheme.gold.withValues(alpha: 0.22),
                          width: 1,
                        ),
                        borderRadius: BorderRadius.circular(6),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(
                      horizontal: padX, vertical: padY),
                  child: MushafPageView(
                    page: page,
                    surahNumber: surahOfPage(pageNum),
                    baseFontSize: state.fontSize * 1.55,
                    inkColor: ink,
                    goldColor: AppTheme.gold,
                    headerColor: state.nightReadingMode
                        ? const Color(0xFF9AC7B6)
                        : AppTheme.emerald,
                    markerStyle: (surah, ayah) => const TextStyle(),
                    onTapAyah: _tanAyah,
                    onLongPressAyah: _longPress,
                    selectedSurah: _selSurah,
                    selectedAyah: _selAyah,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// السورة المعروضة في الصفحة (لعرض اسم السورة)
  int surahOfPage(int page) {
    if (widget.surahNumber != null) return widget.surahNumber!;
    return _firstSurahOfPage(page);
  }

  void _tanAyah(int surah, int ayah) {
    HapticFeedback.selectionClick();
    setState(() {
      _selSurah = surah;
      _selAyah = ayah;
      _selPage = _repo.pageOf(surah, ayah);
    });
    context.read<AppState>().saveProgress(surah, ayah);
  }

  void _longPress(int surah, int ayah) {
    HapticFeedback.mediumImpact();
    setState(() {
      _selSurah = surah;
      _selAyah = ayah;
      _selPage = _repo.pageOf(surah, ayah);
    });
    _showAyahActions(surah, ayah);
  }

  void _showAyahActions(int surah, int ayah) {
    final state = context.read<AppState>();
    final audio = context.read<AudioPlayerService>();
    final text = _repo.ayahsOfSurah(surah)[ayah - 1].text;
    final bookmarked = state.isBookmarked(surah, ayah);

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 12),
              Container(
                width: 44,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.withValues(alpha: 0.35),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  'سورة ${_repo.surahByNumber(surah).shortName} • الآية ${arNum(ayah)}',
                  style: const TextStyle(
                    fontFamily: 'Amiri',
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const SizedBox(height: 6),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  text,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'KFGQPC',
                    fontSize: 19,
                    height: 1.9,
                    color: Theme.of(context).textTheme.bodyLarge?.color,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              ListTile(
                leading: Icon(
                  bookmarked ? Icons.bookmark_remove : Icons.bookmark_add_outlined,
                  color: AppTheme.gold,
                ),
                title: Text(
                  bookmarked ? 'إزالة من العلامات' : 'إضافة إلى العلامات',
                  style: const TextStyle(fontFamily: 'Amiri'),
                ),
                onTap: () {
                  state.toggleBookmark(surah, ayah, text);
                  Navigator.pop(ctx);
                },
              ),
              ListTile(
                leading: const Icon(Icons.play_circle_outline,
                    color: AppTheme.emerald),
                title: const Text('تشغيل التلاوة من هنا',
                    style: TextStyle(fontFamily: 'Amiri')),
                onTap: () async {
                  Navigator.pop(ctx);
                  await audio.playSurah(
                    surah: surah,
                    startAyah: ayah,
                    ayahCount: _repo.surahByNumber(surah).ayahCount,
                    reciterId: state.reciter,
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.copy_rounded, color: AppTheme.emerald),
                title: const Text('نسخ الآية',
                    style: TextStyle(fontFamily: 'Amiri')),
                onTap: () {
                  Clipboard.setData(ClipboardData(
                    text:
                        '$text\n\n﴿ سورة ${_repo.surahByNumber(surah).shortName} - الآية $ayah ﴾',
                  ));
                  Navigator.pop(ctx);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('تم نسخ الآية',
                          style: TextStyle(fontFamily: 'Amiri')),
                      duration: Duration(seconds: 2),
                    ),
                  );
                },
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBottomBar(
    BuildContext context,
    AppState state,
    AudioPlayerService audio,
  ) {
    final scheme = Theme.of(context).colorScheme;
    final isLight = Theme.of(context).brightness == Brightness.light;

    return Container(
      decoration: BoxDecoration(
        color: scheme.surface,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.10),
            blurRadius: 16,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (_selAyah != null && _selSurah != null)
              Container(
                width: double.infinity,
                color: AppTheme.gold.withValues(alpha: 0.12),
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                child: Text(
                  'الآية ${arNum(_selAyah!)} • سورة ${_repo.surahByNumber(_selSurah!).shortName} • الجزء ${arNum(_repo.juzOf(_selSurah!, _selAyah!))} • الصفحة ${arNum(_selPage!)}',
                  style: const TextStyle(
                    fontFamily: 'Amiri',
                    fontSize: 11.5,
                    color: AppTheme.emerald,
                  ),
                ),
              ),
            SizedBox(
              height: 58,
              child: Row(
                children: [
                  const SizedBox(width: 6),
                  // (RTL) أول عنصر في الصف يظهر على اليمين ⇒ الزر الأيمن = الصفحة السابقة
                  IconButton(
                    onPressed: _page > 1 ? () => _goToPage(_page - 1) : null,
                    icon: const Icon(Icons.chevron_right_rounded, size: 26),
                  ),
                  Expanded(
                    child: Center(
                      child: InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: () => _openJumpDialog(context),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 18, vertical: 6),
                          decoration: BoxDecoration(
                            color: AppTheme.emerald.withValues(alpha: 0.10),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.auto_stories_outlined,
                                  size: 14,
                                  color: isLight
                                      ? AppTheme.emerald
                                      : AppTheme.goldLight),
                              const SizedBox(width: 6),
                              Text(
                                'صفحة ${arNum(_page)} / ٦٠٤',
                                style: const TextStyle(
                                  fontFamily: 'Amiri',
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => _openSurahPicker(context),
                    icon: const Icon(Icons.list_rounded, size: 22),
                  ),
                  IconButton(
                    onPressed: _page < 604 ? () => _goToPage(_page + 1) : null,
                    icon: const Icon(Icons.chevron_left_rounded, size: 26),
                  ),
                  const SizedBox(width: 2),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openJumpDialog(BuildContext context) {
    final controller = TextEditingController(text: '$_page');
    showDialog<void>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
          title: const Text('الانتقال إلى صفحة',
              style: TextStyle(fontFamily: 'Amiri')),
          content: TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            autofocus: true,
            decoration: const InputDecoration(
              hintText: '١ - ٦٠٤',
              border: OutlineInputBorder(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child:
                  const Text('إلغاء', style: TextStyle(fontFamily: 'Amiri')),
            ),
            FilledButton(
              onPressed: () {
                final v = int.tryParse(controller.text.trim());
                Navigator.pop(ctx);
                if (v != null) _goToPage(v);
              },
              child: const Text('انتقال',
                  style: TextStyle(fontFamily: 'Amiri')),
            ),
          ],
        ),
      ),
    );
  }

  void _openSurahPicker(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 14),
              const Text('اختر السورة',
                  style: TextStyle(
                      fontFamily: 'Amiri',
                      fontSize: 18,
                      fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Expanded(
                child: ListView.builder(
                  itemCount: _repo.surahs.length,
                  itemBuilder: (c, i) {
                    final s = _repo.surahs[i];
                    return ListTile(
                      dense: true,
                      leading: CircleAvatar(
                        radius: 14,
                        backgroundColor:
                            AppTheme.emerald.withValues(alpha: 0.10),
                        child: Text(
                          arNum(s.number),
                          style: const TextStyle(
                            fontFamily: 'Amiri',
                            fontSize: 11,
                            color: AppTheme.emerald,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      title: Text(
                        s.shortName,
                        style: const TextStyle(fontFamily: 'Amiri', fontSize: 16),
                      ),
                      subtitle: Text(
                        'صفحة ${arNum(_repo.pageOf(s.number, 1))}',
                        style: TextStyle(
                          fontFamily: 'Amiri',
                          fontSize: 11,
                          color: Colors.grey.shade600,
                        ),
                      ),
                      onTap: () {
                        Navigator.pop(ctx);
                        _goToPage(_repo.pageOf(s.number, 1));
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showFontSheet(BuildContext context, AppState state) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: StatefulBuilder(
          builder: (ctx, setSheetState) => SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'حجم خط المصحف',
                    style: TextStyle(
                      fontFamily: 'Amiri',
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      IconButton.filledTonal(
                        onPressed: () async {
                          await state.setFontSize(state.fontSize - 2);
                          setSheetState(() {});
                        },
                        icon: const Icon(Icons.remove),
                      ),
                      Expanded(
                        child: Slider(
                          value: state.fontSize,
                          min: 18,
                          max: 46,
                          divisions: 14,
                          activeColor: AppTheme.emerald,
                          onChanged: (v) async {
                            await state.setFontSize(v);
                            setSheetState(() {});
                          },
                        ),
                      ),
                      IconButton.filledTonal(
                        onPressed: () async {
                          await state.setFontSize(state.fontSize + 2);
                          setSheetState(() {});
                        },
                        icon: const Icon(Icons.add),
                      ),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppTheme.emerald.withValues(alpha: 0.05),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(
                      'وَنُنَزِّلُ مِنَ ٱلْقُرْآنِ',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'KFGQPC',
                        fontSize: state.fontSize,
                        height: 1.8,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
