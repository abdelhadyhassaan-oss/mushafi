import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/quran_repository.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import 'reader_screen.dart';

/// العلامات المرجعية
class BookmarksScreen extends StatelessWidget {
  final bool standalone;
  const BookmarksScreen({super.key, this.standalone = false});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final repo = QuranRepository.instance;
    final isLight = Theme.of(context).brightness == Brightness.light;

    final body = state.bookmarks.isEmpty
        ? _buildEmpty(context)
        : ListView.separated(
            padding: EdgeInsets.fromLTRB(16, 16, 16, standalone ? 30 : 100),
            itemCount: state.bookmarks.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              final b = state.bookmarks[i];
              final surah = repo.surahByNumber(b.surah);
              return Material(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(18),
                child: InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () {
                    if (standalone) {
                      Navigator.of(context).pushReplacement(
                        MaterialPageRoute(
                          builder: (_) => ReaderScreen(
                            surahNumber: b.surah,
                            initialAyah: b.ayah,
                          ),
                        ),
                      );
                    } else {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => ReaderScreen(
                            surahNumber: b.surah,
                            initialAyah: b.ayah,
                          ),
                        ),
                      );
                    }
                  },
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: isLight
                            ? Colors.black.withValues(alpha: 0.06)
                            : Colors.white.withValues(alpha: 0.07),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: AppTheme.gold.withValues(alpha: 0.14),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                '${surah.shortName} • ${b.ayah}',
                                style: const TextStyle(
                                  fontFamily: 'Amiri',
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: AppTheme.emerald,
                                ),
                              ),
                            ),
                            const Spacer(),
                            IconButton(
                              visualDensity: VisualDensity.compact,
                              onPressed: () => state.removeBookmark(b),
                              icon: const Icon(
                                Icons.delete_outline,
                                size: 19,
                                color: Colors.redAccent,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          b.text,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontFamily: 'AmiriQuran',
                            fontSize: 17,
                            height: 1.9,
                            color: isLight ? AppTheme.ink : Colors.white70,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );

    if (standalone) {
      return Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('العلامات المرجعية'),
            backgroundColor: AppTheme.emerald,
            actions: [
              if (state.bookmarks.isNotEmpty)
                IconButton(
                  onPressed: () => _confirmClear(context, state),
                  icon: const Icon(Icons.delete_sweep_outlined),
                ),
            ],
          ),
          body: body,
        ),
      );
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Column(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: AppTheme.headerGradient,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(28),
                bottomRight: Radius.circular(28),
              ),
            ),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 22),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'العلامات المرجعية',
                            style: TextStyle(
                              fontFamily: 'Amiri',
                              fontSize: 24,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '${state.bookmarks.length} علامة محفوظة',
                            style: TextStyle(
                              fontFamily: 'Amiri',
                              fontSize: 12.5,
                              color: Colors.white.withValues(alpha: 0.8),
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (state.bookmarks.isNotEmpty)
                      IconButton(
                        onPressed: () => _confirmClear(context, state),
                        icon: const Icon(
                          Icons.delete_sweep_outlined,
                          color: Colors.white,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(child: body),
        ],
      ),
    );
  }

  void _confirmClear(BuildContext context, AppState state) {
    showDialog<void>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(22),
          ),
          title: const Text(
            'حذف كل العلامات',
            style: TextStyle(fontFamily: 'Amiri'),
          ),
          content: const Text(
            'هل تريد حذف جميع العلامات المرجعية؟',
            style: TextStyle(fontFamily: 'Amiri'),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('إلغاء', style: TextStyle(fontFamily: 'Amiri')),
            ),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: Colors.redAccent),
              onPressed: () {
                state.clearBookmarks();
                Navigator.pop(ctx);
              },
              child: const Text('حذف', style: TextStyle(fontFamily: 'Amiri')),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmpty(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.bookmark_border,
            size: 70,
            color: AppTheme.gold.withValues(alpha: 0.55),
          ),
          const SizedBox(height: 16),
          const Text(
            'لا توجد علامات مرجعية',
            style: TextStyle(
              fontFamily: 'Amiri',
              fontSize: 18,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              'اضغط مطوّلًا على أي آية أثناء القراءة لإضافتها إلى العلامات',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'Amiri',
                fontSize: 13,
                color: Colors.grey.shade600,
                height: 1.6,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
