import 'package:flutter/material.dart';

/// ثيم التطبيق — أخضر زمردي وذهبي بروح إسلامية كلاسيكية
class AppTheme {
  static const Color emerald = Color(0xFF0B5D4A);
  static const Color emeraldDark = Color(0xFF073D31);
  static const Color emeraldLight = Color(0xFF157A63);
  static const Color gold = Color(0xFFC9A227);
  static const Color goldLight = Color(0xFFE7C766);
  static const Color cream = Color(0xFFFBF8F0);
  static const Color parchment = Color(0xFFF5EFDF);
  static const Color ink = Color(0xFF1F2620);

  static const Color darkBg = Color(0xFF0E1512);
  static const Color darkSurface = Color(0xFF16201C);
  static const Color darkCard = Color(0xFF1C2823);

  static ThemeData light() {
    final base = ThemeData.light(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: cream,
      colorScheme: ColorScheme.fromSeed(
        seedColor: emerald,
        primary: emerald,
        secondary: gold,
        surface: Colors.white,
        brightness: Brightness.light,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        foregroundColor: Colors.white,
        titleTextStyle: TextStyle(
          fontFamily: 'Amiri',
          fontSize: 22,
          fontWeight: FontWeight.w700,
          color: Colors.white,
        ),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        margin: EdgeInsets.zero,
      ),
      dividerTheme: const DividerThemeData(
        color: Color(0x11000000),
        thickness: 1,
        space: 1,
      ),
      textTheme: base.textTheme.apply(
        fontFamily: 'Amiri',
        bodyColor: ink,
        displayColor: ink,
      ),
      splashFactory: InkSparkle.splashFactory,
    );
  }

  static ThemeData dark() {
    final base = ThemeData.dark(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: darkBg,
      colorScheme: ColorScheme.fromSeed(
        seedColor: emeraldLight,
        primary: const Color(0xFF37A98C),
        secondary: goldLight,
        surface: darkSurface,
        brightness: Brightness.dark,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        foregroundColor: Colors.white,
        titleTextStyle: TextStyle(
          fontFamily: 'Amiri',
          fontSize: 22,
          fontWeight: FontWeight.w700,
          color: Colors.white,
        ),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: darkCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        margin: EdgeInsets.zero,
      ),
      dividerTheme: const DividerThemeData(
        color: Color(0x22FFFFFF),
        thickness: 1,
        space: 1,
      ),
      textTheme: base.textTheme.apply(
        fontFamily: 'Amiri',
        bodyColor: const Color(0xFFE8EFEA),
        displayColor: const Color(0xFFE8EFEA),
      ),
      splashFactory: InkSparkle.splashFactory,
    );
  }

  /// تدرّج الرأس
  static const LinearGradient headerGradient = LinearGradient(
    begin: Alignment.topRight,
    end: Alignment.bottomLeft,
    colors: [emeraldDark, emerald, emeraldLight],
  );

  static const LinearGradient goldGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [gold, goldLight],
  );
}
