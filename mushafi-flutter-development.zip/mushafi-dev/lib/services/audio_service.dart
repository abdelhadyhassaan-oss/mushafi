import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

/// القارئ المتاح
class Reciter {
  final String id;
  final String name;
  final String folder; // مجلد everyayah أو معرف islamic.network

  const Reciter({required this.id, required this.name, required this.folder});
}

/// قائمة القرّاء
const List<Reciter> kReciters = [
  Reciter(id: 'ar.alafasy', name: 'مشاري العفاسي', folder: 'Alafasy_128kbps'),
  Reciter(
    id: 'ar.abdulbasitmurattal',
    name: 'عبد الباسط (مرتل)',
    folder: 'Abdul_Basit_Murattal_192kbps',
  ),
  Reciter(id: 'ar.husary', name: 'محمود خليل الحصري', folder: 'Husary_128kbps'),
  Reciter(
    id: 'ar.minshawi',
    name: 'محمد صديق المنشاوي',
    folder: 'Minshawy_Murattal_128kbps',
  ),
  Reciter(
    id: 'ar.mahermuaiqly',
    name: 'ماهر المعيقلي',
    folder: 'MaherAlMuaiqly128kbps',
  ),
  Reciter(
    id: 'ar.saoodshuraym',
    name: 'سعود الشريم',
    folder: 'Saood_ash-Shuraym_128kbps',
  ),
  Reciter(
    id: 'ar.ahmedajamy',
    name: 'أحمد العجمي',
    folder: 'ahmed_ajax_128kbps',
  ),
  Reciter(
    id: 'ar.muhammadayyoub',
    name: 'محمد أيوب',
    folder: 'Muhammad_Ayyoub_128kbps',
  ),
];

Reciter reciterById(String id) =>
    kReciters.firstWhere((r) => r.id == id, orElse: () => kReciters.first);

/// مشغّل تلاوة الآيات — يدعم التشغيل المتتالي والتحكم الكامل
class AudioPlayerService extends ChangeNotifier {
  final AudioPlayer _player = AudioPlayer();

  List<String> _urls = <String>[];
  int _currentIndex = 0;
  bool _isPlaying = false;
  bool _loading = false;
  bool _autoAdvance = true;

  int get currentIndex => _currentIndex;
  bool get isPlaying => _isPlaying;
  bool get isLoading => _loading;
  bool get autoAdvance => _autoAdvance;
  bool get hasQueue => _urls.isNotEmpty;

  AudioPlayerService() {
    _player.playerStateStream.listen((state) {
      _isPlaying =
          state.playing && state.processingState != ProcessingState.completed;
      notifyListeners();
    });
    _player.processingStateStream.listen((state) {
      if (state == ProcessingState.completed) {
        _onCompleted();
      }
    });
  }

  void toggleAutoAdvance() {
    _autoAdvance = !_autoAdvance;
    notifyListeners();
  }

  /// بناء رابط الصوت لآية
  static String ayahUrl({
    required int surah,
    required int ayah,
    required String reciterId,
  }) {
    final s = surah.toString().padLeft(3, '0');
    final a = ayah.toString().padLeft(3, '0');
    return 'https://everyayah.com/data/${reciterById(reciterId).folder}/$s$a.mp3';
  }

  /// تشغيل سورة كاملة بدءًا من آية معينة
  Future<void> playSurah({
    required int surah,
    required int startAyah,
    required int ayahCount,
    required String reciterId,
  }) async {
    _urls = List.generate(
      ayahCount - startAyah + 1,
      (i) => ayahUrl(surah: surah, ayah: startAyah + i, reciterId: reciterId),
    );
    _currentIndex = 0;
    await _playIndex(0);
  }

  /// تشغيل آية واحدة
  Future<void> playSingle({
    required int surah,
    required int ayah,
    required String reciterId,
  }) async {
    _urls = [ayahUrl(surah: surah, ayah: ayah, reciterId: reciterId)];
    _currentIndex = 0;
    await _playIndex(0);
  }

  Future<void> _playIndex(int index) async {
    if (index < 0 || index >= _urls.length) return;
    _currentIndex = index;
    _loading = true;
    notifyListeners();
    try {
      await _player.setUrl(_urls[index]);
      _loading = false;
      notifyListeners();
      await _player.play();
    } catch (_) {
      _loading = false;
      _isPlaying = false;
      notifyListeners();
    }
  }

  void _onCompleted() {
    if (_autoAdvance && _currentIndex < _urls.length - 1) {
      _playIndex(_currentIndex + 1);
    } else {
      _isPlaying = false;
      notifyListeners();
    }
  }

  Future<void> toggle() async {
    if (_isPlaying) {
      await _player.pause();
    } else {
      if (_urls.isEmpty) return;
      await _player.play();
    }
  }

  Future<void> next() async {
    if (_currentIndex < _urls.length - 1) {
      await _playIndex(_currentIndex + 1);
    }
  }

  Future<void> previous() async {
    if (_currentIndex > 0) {
      await _playIndex(_currentIndex - 1);
    }
  }

  Future<void> stop() async {
    _urls = <String>[];
    _currentIndex = 0;
    _isPlaying = false;
    await _player.stop();
    notifyListeners();
  }

  /// الآية الحالية في قائمة التشغيل (بالفهرس داخل السورة)
  int get currentOffset => _currentIndex;

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }
}
