import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;

/// مقطع آية داخل سطر بمصحف المدينة
class LineSegment {
  final int surah;
  final int ayah;
  final String text;
  /// هل ينتهي هذا المقطع بعلامة نهاية آية (رقم الآية)
  final bool endsAyah;

  const LineSegment({
    required this.surah,
    required this.ayah,
    required this.text,
    required this.endsAyah,
  });

  factory LineSegment.fromJson(Map<String, dynamic> j) => LineSegment(
        surah: j['s'] as int,
        ayah: j['a'] as int,
        text: j['txt'] as String? ?? '',
        endsAyah: j['end'] as bool? ?? false,
      );
}

/// سطر من سطور صفحة المصحف
class MushafLine {
  final int number; // 1..15
  final List<LineSegment> segments;

  const MushafLine({required this.number, required this.segments});

  factory MushafLine.fromJson(Map<String, dynamic> j) => MushafLine(
        number: j['n'] as int,
        segments: (j['segs'] as List)
            .map((e) => LineSegment.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}

/// صفحة من مصحف المدينة (15 سطرًا)
class MushafPage {
  final int number;
  final List<MushafLine> lines;

  /// فهرس السطر (1..15) الذي يحمل اسم السورة ⇒ رقم السورة
  final Map<int, int> banners;

  /// السور التي تبدأ في هذه الصفحة
  final List<int> starts;

  const MushafPage({
    required this.number,
    required this.lines,
    required this.banners,
    required this.starts,
  });

  factory MushafPage.fromJson(int number, Map<String, dynamic> j) => MushafPage(
        number: number,
        lines: (j['lines'] as List)
            .map((e) => MushafLine.fromJson(e as Map<String, dynamic>))
            .toList(),
        banners: (j['banner'] as Map<String, dynamic>).map(
          (k, v) => MapEntry(int.parse(k), v as int),
        ),
        starts: (j['starts'] as List).map((e) => e as int).toList(),
      );
}

/// مستودع بيانات القرآن الكريم — نص عثماني + صفحات مصحف المدينة
class QuranRepository {
  QuranRepository._();
  static final QuranRepository instance = QuranRepository._();

  List<Surah> _surahs = <Surah>[];
  List<Ayah> _ayahs = <Ayah>[];
  List<MushafPage> _pages = <MushafPage>[];

  bool _loaded = false;
  bool get isLoaded => _loaded;

  List<Surah> get surahs => _surahs;
  List<Ayah> get ayahs => _ayahs;
  List<MushafPage> get pages => _pages;
  int get pageCount => _pages.length;

  Future<void> load() async {
    if (_loaded) return;
    final quranRaw = await rootBundle.loadString('assets/data/quran.json');
    final Map<String, dynamic> quran =
        json.decode(quranRaw) as Map<String, dynamic>;

    _surahs = (quran['surahs'] as List)
        .map((e) => Surah.fromJson(e as Map<String, dynamic>))
        .toList();
    _ayahs = (quran['ayahs'] as List)
        .map((e) => Ayah.fromJson(e as Map<String, dynamic>))
        .toList();

    final rawPages = quran['pages'] as Map<String, dynamic>;
    _pages = List<MushafPage>.generate(604, (i) {
      final key = '${i + 1}';
      return MushafPage.fromJson(i + 1, rawPages[key] as Map<String, dynamic>);
    });

    _loaded = true;
  }

  Surah surahByNumber(int n) => _surahs[n - 1];

  /// فهرس الآية العالمي (0-based)
  int globalIndex(int surah, int ayahInSurah) =>
      _surahs[surah - 1].startIndex - 1 + (ayahInSurah - 1);

  Ayah ayahAt(int globalIdx) => _ayahs[globalIdx];

  List<Ayah> ayahsOfSurah(int surahNumber) {
    final s = surahByNumber(surahNumber);
    final start = s.startIndex - 1;
    return _ayahs.sublist(start, start + s.ayahCount);
  }

  /// تحديد موقع آية عالمية: السورة ورقم الآية
  ({int surah, int ayah}) locateGlobal(int globalIdx) {
    var low = 0, high = _surahs.length - 1;
    while (low <= high) {
      final mid = (low + high) ~/ 2;
      final s = _surahs[mid];
      final start = s.startIndex - 1;
      if (globalIdx < start) {
        high = mid - 1;
      } else if (globalIdx >= start + s.ayahCount) {
        low = mid + 1;
      } else {
        return (surah: s.number, ayah: globalIdx - start + 1);
      }
    }
    return (surah: 1, ayah: 1);
  }

  /// رقم الصفحة التي تحتوي آية معيّنة
  int pageOf(int surah, int ayah) => _ayahs[globalIndex(surah, ayah)].page;

  /// رقم الجزء لآية
  int juzOf(int surah, int ayah) => _ayahs[globalIndex(surah, ayah)].juz;

  /// آليات الأجزاء: (رقم الجزء ⇒ أول صفحة)
  /// يستخدم لتحديد الجزء من الصفحة
  int juzOfPage(int page) {
    // أول آية في الصفحة
    final p = _pages[page - 1];
    for (final line in p.lines) {
      for (final seg in line.segments) {
        return juzOf(seg.surah, seg.ayah);
      }
    }
    return 1;
  }

  /// رقم صفحة بداية الجزء
  int pageOfJuz(int juz) {
    for (var p = 1; p <= 604; p++) {
      final page = _pages[p - 1];
      for (final line in page.lines) {
        for (final seg in line.segments) {
          final j = juzOf(seg.surah, seg.ayah);
          if (j == juz) return p;
          if (j > juz) return p;
        }
      }
    }
    return 1;
  }

  /// تجريد التشكيل لتسهيل البحث
  static String normalize(String input) {
    final buffer = StringBuffer();
    for (final rune in input.runes) {
      if ((rune >= 0x0610 && rune <= 0x061A) ||
          (rune >= 0x064B && rune <= 0x065F) ||
          rune == 0x0670 ||
          (rune >= 0x06D6 && rune <= 0x06ED) ||
          rune == 0x0640 ||
          rune == 0xFEFF) {
        continue;
      }
      var ch = String.fromCharCode(rune);
      if (ch == 'ٱ' || ch == 'أ' || ch == 'إ' || ch == 'آ') ch = 'ا';
      if (ch == 'ى') ch = 'ي';
      if (ch == 'ة') ch = 'ه';
      if (ch == 'ؤ') ch = 'و';
      if (ch == 'ئ') ch = 'ي';
      buffer.write(ch);
    }
    return buffer.toString();
  }

  List<SearchHit> search(String query, {int limit = 200}) {
    final q = normalize(query).trim();
    if (q.length < 2) return const [];
    final hits = <SearchHit>[];
    for (var i = 0; i < _ayahs.length; i++) {
      if (normalize(_ayahs[i].text).contains(q)) {
        hits.add(SearchHit(globalIndex: i, ayah: _ayahs[i]));
        if (hits.length >= limit) break;
      }
    }
    return hits;
  }
}

/// سورة
class Surah {
  final int number;
  final String name;
  final String englishName;
  final String englishTranslation;
  final String type;
  final int ayahCount;
  final int startIndex;

  const Surah({
    required this.number,
    required this.name,
    required this.englishName,
    required this.englishTranslation,
    required this.type,
    required this.ayahCount,
    required this.startIndex,
  });

  factory Surah.fromJson(Map<String, dynamic> j) => Surah(
        number: j['n'] as int,
        name: j['name'] as String,
        englishName: j['en'] as String? ?? '',
        englishTranslation: j['enT'] as String? ?? '',
        type: j['type'] as String? ?? '',
        ayahCount: j['count'] as int,
        startIndex: j['start'] as int,
      );

  String get shortName => name.replaceFirst('سُورَةُ ', '');
}

/// آية
class Ayah {
  final String text;
  final int page;
  final int juz;

  const Ayah({required this.text, required this.page, required this.juz});

  factory Ayah.fromJson(Map<String, dynamic> j) => Ayah(
        text: j['t'] as String,
        page: j['p'] as int,
        juz: j['j'] as int,
      );
}

class SearchHit {
  final int globalIndex;
  final Ayah ayah;
  const SearchHit({required this.globalIndex, required this.ayah});
}
