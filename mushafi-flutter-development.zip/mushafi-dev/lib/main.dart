import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'data/quran_repository.dart';
import 'screens/home_screen.dart';
import 'screens/reader_screen.dart';
import 'services/audio_service.dart';
import 'state/app_state.dart';
import 'theme/app_theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      statusBarBrightness: Brightness.dark,
    ),
  );

  final appState = AppState();
  await appState.init();
  await QuranRepository.instance.load();

  runApp(MushafApp(appState: appState));
}

class MushafApp extends StatelessWidget {
  final AppState appState;
  const MushafApp({super.key, required this.appState});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<AppState>.value(value: appState),
        ChangeNotifierProvider<AudioPlayerService>(
          create: (_) => AudioPlayerService(),
        ),
      ],
      child: Consumer<AppState>(
        builder: (context, state, _) => MaterialApp(
          title: 'المصحف الشريف',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.light(),
          darkTheme: AppTheme.dark(),
          themeMode: state.themeMode,
          locale: const Locale('ar'),
          builder: (context, child) => Directionality(
            textDirection: TextDirection.rtl,
            child: child ?? const SizedBox.shrink(),
          ),
          home: _initialRoute(),
        ),
      ),
    );
  }

  /// يسمح بفتح صفحة محددة مباشرة عبر رابط الويب مثل: ?page=50
  Widget _initialRoute() {
    final p = int.tryParse(Uri.base.queryParameters['page'] ?? '');
    if (p != null && p >= 1 && p <= 604) {
      return ReaderScreen(pageNumber: p);
    }
    return const HomeScreen();
  }
}
