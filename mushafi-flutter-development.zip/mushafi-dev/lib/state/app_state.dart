import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// علامة مرجعية محفوظة
class Bookmark {
  final int surah;
  final int ayah;
  final String text;
  final DateTime savedAt;

  const Bookmark({
    required this.surah,
    required this.ayah,
    required this.text,
    required this.savedAt,
  });

  Map<String, dynamic> toJson() => {
    's': surah,
    'a': ayah,
    't': text,
    'd': savedAt.millisecondsSinceEpoch,
  };

  factory Bookmark.fromJson(Map<String, dynamic> j) => Bookmark(
    surah: j['s'] as int,
    ayah: j['a'] as int,
    text: j['t'] as String? ?? '',
    savedAt: DateTime.fromMillisecondsSinceEpoch(
      (j['d'] as num?)?.toInt() ?? 0,
    ),
  );

  String get key => '$surah:$ayah';
}

/// حالة التطبيق العامة: الثيم، حجم الخط، العلامات، آخر موضع قراءة
class AppState extends ChangeNotifier {
  static const _kDark = 'dark_mode';
  static const _kFontSize = 'font_size';
  static const _kBookmarks = 'bookmarks';
  static const _kLastSurah = 'last_surah';
  static const _kLastAyah = 'last_ayah';
  static const _kReciter = 'reciter';
  static const _kTajweed = 'show_tajweed';

  SharedPreferences? _prefs;

  bool _darkMode = false;
  double _fontSize = 26;
  List<Bookmark> _bookmarks = <Bookmark>[];
  int _lastSurah = 1;
  int _lastAyah = 1;
  String _reciter = 'ar.alafasy';
  bool _nightReadingMode = false;

  bool get darkMode => _darkMode;
  double get fontSize => _fontSize;
  List<Bookmark> get bookmarks => _bookmarks;
  int get lastSurah => _lastSurah;
  int get lastAyah => _lastAyah;
  String get reciter => _reciter;
  bool get nightReadingMode => _nightReadingMode;
  bool get hasProgress => _lastSurah > 1 || _lastAyah > 1;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    final p = _prefs!;
    _darkMode = p.getBool(_kDark) ?? false;
    _fontSize = (p.getDouble(_kFontSize) ?? 26).clamp(18.0, 46.0);
    _lastSurah = (p.getInt(_kLastSurah) ?? 1).clamp(1, 114);
    _lastAyah = (p.getInt(_kLastAyah) ?? 1).clamp(1, 286);
    _reciter = p.getString(_kReciter) ?? 'ar.alafasy';
    _nightReadingMode = p.getBool(_kTajweed) ?? false;

    final raw = p.getString(_kBookmarks);
    if (raw != null && raw.isNotEmpty) {
      try {
        final list = json.decode(raw) as List;
        _bookmarks = list
            .map((e) => Bookmark.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {
        _bookmarks = <Bookmark>[];
      }
    }
    notifyListeners();
  }

  Future<void> toggleDark() async {
    _darkMode = !_darkMode;
    notifyListeners();
    await _prefs?.setBool(_kDark, _darkMode);
  }

  Future<void> setFontSize(double v) async {
    _fontSize = v.clamp(18.0, 46.0);
    notifyListeners();
    await _prefs?.setDouble(_kFontSize, _fontSize);
  }

  Future<void> setReciter(String id) async {
    _reciter = id;
    notifyListeners();
    await _prefs?.setString(_kReciter, id);
  }

  Future<void> toggleNightReading() async {
    _nightReadingMode = !_nightReadingMode;
    notifyListeners();
    await _prefs?.setBool(_kTajweed, _nightReadingMode);
  }

  Future<void> saveProgress(int surah, int ayah) async {
    if (_lastSurah == surah && _lastAyah == ayah) return;
    _lastSurah = surah;
    _lastAyah = ayah;
    notifyListeners();
    await _prefs?.setInt(_kLastSurah, surah);
    await _prefs?.setInt(_kLastAyah, ayah);
  }

  bool isBookmarked(int surah, int ayah) =>
      _bookmarks.any((b) => b.surah == surah && b.ayah == ayah);

  Future<void> toggleBookmark(int surah, int ayah, String text) async {
    final idx = _bookmarks.indexWhere(
      (b) => b.surah == surah && b.ayah == ayah,
    );
    if (idx >= 0) {
      _bookmarks.removeAt(idx);
    } else {
      _bookmarks.insert(
        0,
        Bookmark(surah: surah, ayah: ayah, text: text, savedAt: DateTime.now()),
      );
    }
    notifyListeners();
    await _persistBookmarks();
  }

  Future<void> removeBookmark(Bookmark b) async {
    _bookmarks.removeWhere((e) => e.key == b.key);
    notifyListeners();
    await _persistBookmarks();
  }

  Future<void> clearBookmarks() async {
    _bookmarks.clear();
    notifyListeners();
    await _persistBookmarks();
  }

  Future<void> _persistBookmarks() async {
    final raw = json.encode(_bookmarks.map((e) => e.toJson()).toList());
    await _prefs?.setString(_kBookmarks, raw);
  }

  ThemeMode get themeMode => _darkMode ? ThemeMode.dark : ThemeMode.light;
}
