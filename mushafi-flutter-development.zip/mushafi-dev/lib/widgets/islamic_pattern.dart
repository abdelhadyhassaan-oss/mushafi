import 'package:flutter/material.dart';

/// زخرفة إسلامية بسيطة مرسومة برمجيًا (نجمة ثمانية متداخلة)
class IslamicPattern extends StatelessWidget {
  final double size;
  final Color color;
  final double strokeWidth;
  final int opacityPercent;

  const IslamicPattern({
    super.key,
    this.size = 120,
    this.color = Colors.white,
    this.strokeWidth = 1.2,
    this.opacityPercent = 14,
  });

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Opacity(
        opacity: opacityPercent / 100,
        child: CustomPaint(
          size: Size.square(size),
          painter: _PatternPainter(color: color, strokeWidth: strokeWidth),
        ),
      ),
    );
  }
}

class _PatternPainter extends CustomPainter {
  final Color color;
  final double strokeWidth;
  _PatternPainter({required this.color, required this.strokeWidth});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth;

    final c = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2;

    // مربعان متقاطعان (نجمة ثمانية)
    for (var i = 0; i < 2; i++) {
      canvas.save();
      canvas.translate(c.dx, c.dy);
      canvas.rotate(i * 3.14159 / 4);
      canvas.drawRect(
        Rect.fromCenter(center: Offset.zero, width: r * 1.55, height: r * 1.55),
        paint,
      );
      canvas.restore();
    }

    // دائرة خارجية
    canvas.drawCircle(c, r * 0.92, paint);
    canvas.drawCircle(c, r * 0.62, paint);

    // دوائر صغيرة على المحيط
    for (var i = 0; i < 8; i++) {
      final a = i * 3.14159 / 4;
      canvas.drawCircle(
        Offset(c.dx + r * 0.78 * _cos(a), c.dy + r * 0.78 * _sin(a)),
        r * 0.07,
        paint,
      );
    }
  }

  double _cos(double a) => _c(a);
  double _sin(double a) => _s(a);
  double _c(double a) {
    // تقريب كافٍ للرسم
    const vals = [1.0, 0.7071, 0.0, -0.7071, -1.0, -0.7071, 0.0, 0.7071];
    final idx = ((a / (3.14159 / 4)).round()) % 8;
    return vals[idx.abs() % 8];
  }

  double _s(double a) => _c(a - 3.14159 / 2);

  @override
  bool shouldRepaint(covariant _PatternPainter old) =>
      old.color != color || old.strokeWidth != strokeWidth;
}

/// فاصل زخرفي بين السور
class OrnamentDivider extends StatelessWidget {
  final Color color;
  const OrnamentDivider({super.key, this.color = const Color(0xFFC9A227)});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Divider(color: color.withValues(alpha: 0.35))),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Icon(Icons.diamond_outlined, size: 14, color: color),
        ),
        Expanded(child: Divider(color: color.withValues(alpha: 0.35))),
      ],
    );
  }
}

/// إطار مزخرف لبطاقة
class OrnateFrame extends StatelessWidget {
  final Widget child;
  final Color borderColor;
  final Color fillColor;
  final double radius;

  const OrnateFrame({
    super.key,
    required this.child,
    this.borderColor = const Color(0xFFC9A227),
    this.fillColor = Colors.white,
    this.radius = 22,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: fillColor,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(
          color: borderColor.withValues(alpha: 0.5),
          width: 1.4,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: child,
    );
  }
}
