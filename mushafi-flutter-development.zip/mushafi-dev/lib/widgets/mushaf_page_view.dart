import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../data/quran_repository.dart';
import '../utils/arabic.dart';

/// عرض صفحة مصحف المدينة: ١٥ سطرًا، خط مجمع الملك فهد، وضبط تلقائي لحجم الخط
/// مع **توزيع المسافات بين الكلمات بالتساوي** حتى تصل بداية كل سطر ونهايته
/// إلى حدّي الصفحة تمامًا كما في المصحف المطبوع.
class MushafPageView extends StatefulWidget {
  final MushafPage page;
  final int surahNumber; // السورة المعروضة (لعنوان السورة)
  final double baseFontSize;
  final Color inkColor;
  final Color goldColor;
  final Color headerColor;
  final TextStyle Function(int surah, int ayah) markerStyle;
  final void Function(int surah, int ayah) onTapAyah;
  final void Function(int surah, int ayah) onLongPressAyah;
  final int? selectedSurah;
  final int? selectedAyah;

  const MushafPageView({
    super.key,
    required this.page,
    required this.surahNumber,
    required this.baseFontSize,
    required this.inkColor,
    required this.goldColor,
    required this.headerColor,
    required this.markerStyle,
    required this.onTapAyah,
    required this.onLongPressAyah,
    this.selectedSurah,
    this.selectedAyah,
  });

  @override
  State<MushafPageView> createState() => _MushafPageViewState();
}

class _MushafPageViewState extends State<MushafPageView> {
  final List<TapGestureRecognizer> _taps = [];
  final List<LongPressGestureRecognizer> _longPresses = [];

  static const int totalLines = 15;

  /// حجم مرجعي للقياس
  static const double _measureSize = 100.0;

  /// أقصى مسافة مسموحة بين الكلمات (بعدها يُوسَّط السطر كما في المطبوع).
  /// صغيرة عمدًا حتى تبقى الكلمات متلاصقة كما في المصحف المطبوع، فلا تُفرَّج
  /// الأسطر القصيرة، بل تُوسَّط.
  static const double _maxSpaceRatio = 0.62;

  /// مسافة طبيعية بين الكلمات عند عدم الحاجة للتمديد
  static const double _baseSpaceRatio = 0.14;

  @override
  void dispose() {
    _disposeRecognizers();
    super.dispose();
  }

  void _disposeRecognizers() {
    for (final r in _taps) {
      r.dispose();
    }
    for (final r in _longPresses) {
      r.dispose();
    }
    _taps.clear();
    _longPresses.clear();
  }

  /// بناء مقاطع النص لسطر معيّن.
  /// [wordSpacing] تُطبّق على كل مسافة بين الكلمات (وهكذا يمتد السطر كما في
  /// المصحف المطبوع). [interactive] تفعيل اللمس، [highlight] تمييز الآية.
  List<InlineSpan> _spansFor(
    MushafLine line,
    double fontSize,
    Color ink, {
    double wordSpacing = 0,
    bool interactive = false,
    bool highlight = true,
  }) {
    final spans = <InlineSpan>[];
    final segs = line.segments;

    TextStyle styleOf({required bool selected}) => TextStyle(
          fontFamily: 'KFGQPC',
          fontSize: fontSize,
          height: 1.0,
          wordSpacing: wordSpacing,
          color: selected ? widget.headerColor : ink,
          backgroundColor:
              selected ? widget.goldColor.withValues(alpha: 0.26) : null,
        );

    final spaceStyle = TextStyle(
      fontFamily: 'KFGQPC',
      fontSize: fontSize,
      height: 1.0,
      wordSpacing: wordSpacing,
    );

    for (var i = 0; i < segs.length; i++) {
      final seg = segs[i];
      final selected = highlight &&
          widget.selectedSurah == seg.surah &&
          widget.selectedAyah == seg.ayah;

      TapGestureRecognizer? tap;
      LongPressGestureRecognizer? longPress;
      if (interactive) {
        tap = TapGestureRecognizer()
          ..onTap = () => widget.onTapAyah(seg.surah, seg.ayah);
        longPress = LongPressGestureRecognizer()
          ..onLongPress = () => widget.onLongPressAyah(seg.surah, seg.ayah);
        _taps.add(tap);
        _longPresses.add(longPress);
      }

      final style = styleOf(selected: selected);

      if (seg.text.isNotEmpty) {
        spans.add(TextSpan(text: seg.text, style: style, recognizer: tap));
      }

      // رقم الآية: الأرقام العربية تُرسم داخل الزخرفة في خط مجمع الملك فهد
      if (seg.endsAyah) {
        if (seg.text.isNotEmpty) {
          spans.add(TextSpan(text: ' ', style: spaceStyle, recognizer: tap));
        }
        spans.add(
          TextSpan(text: arNum(seg.ayah), style: style, recognizer: tap),
        );
      }

      if (i < segs.length - 1) {
        spans.add(TextSpan(text: ' ', style: spaceStyle, recognizer: tap));
      }
    }
    return spans;
  }

  /// قياس عرض السطر (بدون أي تمديد) + عدد المسافات فيه
  ({double width, int spaces}) _measureLine(MushafLine line) {
    final spans = _spansFor(
      line,
      _measureSize,
      widget.inkColor,
      highlight: false,
    );
    final painter = TextPainter(
      text: TextSpan(children: spans),
      textDirection: TextDirection.rtl,
      textScaler: TextScaler.noScaling,
    )..layout();

    final w = painter.width;
    painter.dispose();

    var spaces = 0;
    for (final s in spans) {
      final t = (s as TextSpan).text;
      if (t == null) continue;
      for (final ch in t.split('')) {
        if (ch == ' ') spaces++;
      }
    }
    return (width: w, spaces: spaces);
  }

  @override
  Widget build(BuildContext context) {
    _disposeRecognizers();

    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final height = constraints.maxHeight;
        final lineHeight = height / totalLines;

        final lines = widget.page.lines;

        // 1) قياس كل سطر عند الحجم المرجعي
        final measured = <int, ({double width, int spaces})>{};
        final totals = <int, double>{};
        for (final line in lines) {
          final m = _measureLine(line);
          measured[line.number] = m;
          totals[line.number] =
              m.width + m.spaces * (_measureSize * _baseSpaceRatio);
        }

        // 1.1) مرجع العرض: أعرض سطر مع تجاهل السطور القصيرة (نهاية السورة)
        final sorted = totals.values.toList()..sort();
        double reference = sorted.isEmpty ? 0 : sorted.last;
        if (sorted.length > 4) {
          final p90 = sorted[(sorted.length * 0.9).floor().clamp(
                0,
                sorted.length - 1,
              )];
          if (p90 > 0) reference = p90;
        }

        // 2) حجم خط موحّد للصفحة يملأ عرض الصفحة كما في المطبوع
        double fontSize;
        // 1.06: جسم الحرف يشغل معظم ارتفاع السطر (كثافة المصحف المطبوع)
        final byHeight = lineHeight / 1.06;
        if (reference > 0) {
          final byWidth = _measureSize * (width / reference);
          fontSize = byWidth < byHeight ? byWidth : byHeight;
        } else {
          fontSize = byHeight;
        }
        // مفتاح الحجم من الإعدادات يعمل كمكبّر/مصغّر نسبي
        fontSize *= (widget.baseFontSize / 40.0).clamp(0.75, 1.35);
        fontSize = fontSize.clamp(8.0, 70.0);

        // 3) ترتيب صفوف الصفحة: رأس السورة + البسملة + سطور الآيات
        final lineByRow = <int, MushafLine>{
          for (final l in lines) l.number: l,
        };
        final bannerRows = <int, int>{};
        final basmalaRows = <int>{};

        final bannerEntries = widget.page.banners.entries.toList()
          ..sort((a, b) => a.key.compareTo(b.key));
        for (final e in bannerEntries) {
          var row = e.key;
          final surah = e.value;
          if (surah != 1 && surah != 9) {
            final freeAbove = row > 1 &&
                !lineByRow.containsKey(row - 1) &&
                !widget.page.banners.containsKey(row - 1);
            final freeBelow = !lineByRow.containsKey(row + 1) &&
                !widget.page.banners.containsKey(row + 1) &&
                !bannerRows.containsKey(row + 1);
            if (freeAbove) {
              bannerRows[row - 1] = surah;
              basmalaRows.add(row);
              continue;
            } else if (freeBelow) {
              basmalaRows.add(row + 1);
            }
          }
          bannerRows[row] = surah;
        }

        // 4) بناء الصفوف
        final widgets = <Widget>[];
        for (var ln = 1; ln <= totalLines; ln++) {
          final banner = bannerRows[ln];
          if (banner != null) {
            widgets.add(
              SizedBox(
                height: lineHeight,
                child: _buildSurahBanner(banner, lineHeight),
              ),
            );
            continue;
          }

          if (basmalaRows.contains(ln)) {
            widgets.add(
              SizedBox(height: lineHeight, child: _buildBasmala(fontSize)),
            );
            continue;
          }

          final line = lineByRow[ln];
          if (line == null) continue;

          final m = measured[line.number]!;
          final content = m.width * (fontSize / _measureSize);

          // تمديد السطر: توزيع المتبقي على كل المسافات فيه
          var spacing = fontSize * _baseSpaceRatio;
          var centered = false;
          if (m.spaces > 0) {
            final needed = (width - content) / m.spaces;
            if (needed > fontSize * _maxSpaceRatio) {
              centered = true; // سطر قصير (نهاية سورة) ⇒ يُوسَّط
            } else if (needed > 0) {
              spacing = needed;
            }
          } else {
            centered = true;
          }

          final spans = _spansFor(
            line,
            fontSize,
            widget.inkColor,
            wordSpacing: spacing,
            interactive: true,
          );

          widgets.add(
            SizedBox(
              height: lineHeight,
              child: Align(
                alignment: centered ? Alignment.center : Alignment.centerRight,
                child: SizedBox(
                  width: width,
                  child: RichText(
                    textScaler: TextScaler.noScaling,
                    textDirection: TextDirection.rtl,
                    textAlign: centered ? TextAlign.center : TextAlign.right,
                    maxLines: 1,
                    overflow: TextOverflow.visible,
                    text: TextSpan(children: spans),
                  ),
                ),
              ),
            ),
          );
        }

        // 5) توسيط الصفحات القصيرة رأسيًا (مثل صفحة الفاتحة)
        final fill = widgets.length * lineHeight;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: fill < height - lineHeight
              ? MainAxisAlignment.center
              : MainAxisAlignment.start,
          children: widgets,
        );
      },
    );
  }

  /// سطر البسملة (وسط الصفحة مثل المطبوع)
  Widget _buildBasmala(double fontSize) {
    return Align(
      alignment: Alignment.center,
      child: FittedBox(
        fit: BoxFit.scaleDown,
        child: Text(
          'بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ',
          textDirection: TextDirection.rtl,
          maxLines: 1,
          style: TextStyle(
            fontFamily: 'KFGQPC',
            fontSize: fontSize,
            height: 1.0,
            color: widget.inkColor,
          ),
        ),
      ),
    );
  }

  /// شريط اسم السورة المزخرف (كالمصحف المطبوع: إطار ذهبي وخطوط جانبية)
  Widget _buildSurahBanner(int surahNum, double lineHeight) {
    final s = QuranRepository.instance.surahByNumber(surahNum);
    final gold = widget.goldColor;
    final inner = lineHeight * 0.94;

    Widget side({required bool mirrored}) {
      final items = <Widget>[
        Expanded(
          child: Container(height: 1.4, color: gold.withValues(alpha: 0.5)),
        ),
        const SizedBox(width: 5),
        Icon(
          Icons.diamond_outlined,
          size: inner * 0.30,
          color: gold.withValues(alpha: 0.8),
        ),
        const SizedBox(width: 5),
        Container(
          width: inner * 0.14,
          height: inner * 0.14,
          decoration: BoxDecoration(
            color: gold.withValues(alpha: 0.6),
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: 5),
        Container(
          height: 1.4,
          width: 12,
          color: gold.withValues(alpha: 0.5),
        ),
      ];
      return Expanded(
        child: Row(children: mirrored ? items.reversed.toList() : items),
      );
    }

    return Center(
      child: Row(
        children: [
          side(mirrored: false),
          Container(
            height: inner,
            padding: EdgeInsets.symmetric(horizontal: inner * 0.34),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  gold.withValues(alpha: 0.18),
                  gold.withValues(alpha: 0.04),
                ],
              ),
              border: Border.all(
                color: gold.withValues(alpha: 0.85),
                width: 1.3,
              ),
              borderRadius: BorderRadius.circular(inner * 0.22),
            ),
            child: Center(
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  'سورة ${s.shortName}',
                  textDirection: TextDirection.rtl,
                  maxLines: 1,
                  style: TextStyle(
                    fontFamily: 'Amiri',
                    fontSize: inner * 0.44,
                    height: 1.0,
                    fontWeight: FontWeight.w700,
                    color: widget.headerColor,
                  ),
                ),
              ),
            ),
          ),
          side(mirrored: true),
        ],
      ),
    );
  }
}
