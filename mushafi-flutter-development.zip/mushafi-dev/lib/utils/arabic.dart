/// أدوات تنسيق عربية
const List<String> _western = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
const List<String> _arabicIndic = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];

/// تحويل رقم إلى أرقام عربية هندية (٠١٢٣٤٥٦٧٨٩)
String arNum(int n) {
  final buffer = StringBuffer();
  for (final ch in n.toString().split('')) {
    final idx = _western.indexOf(ch);
    buffer.write(idx < 0 ? ch : _arabicIndic[idx]);
  }
  return buffer.toString();
}
